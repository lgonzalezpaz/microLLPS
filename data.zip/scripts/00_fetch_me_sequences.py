#!/usr/bin/env python3
"""
00_fetch_me_sequences.py
Extract the sense-strand nucleotide sequence of every microexon event from the
Ensembl GRCh38 primary assembly (release 115), streaming one chromosome at a time.
Output: data/raw/me_sequences.tsv (event, region, me_seq)
"""
import gzip, sys
import pandas as pd

RAW = sys.argv[1] if len(sys.argv) > 1 else "data/raw"
ev = pd.read_csv(f"{RAW}/MicEvents.hg38.tab.gz", sep="\t")
ev["chrom"] = ev["chrom"].str.replace("chr", "", regex=False)
plus = ev.strand == "+"
ev.loc[plus, "s"] = ev.loc[plus, "upIntEnd"] + 1;  ev.loc[plus, "e"] = ev.loc[plus, "dnIntStart"] - 1
ev.loc[~plus, "s"] = ev.loc[~plus, "dnIntEnd"] + 1; ev.loc[~plus, "e"] = ev.loc[~plus, "upIntStart"] - 1
ev[["s", "e"]] = ev[["s", "e"]].astype(int)
need = set(ev.chrom)
comp = str.maketrans("ACGTN", "TGCAN")
seqs = {}

def flush(name, buf):
    if name in need:
        chrom = "".join(buf).upper()
        for r in ev[ev.chrom == name].itertuples():
            s = chrom[r.s - 1:r.e]
            seqs[r.event] = s if r.strand == "+" else s[::-1].translate(comp)

with gzip.open(f"{RAW}/Homo_sapiens.GRCh38.dna.primary_assembly.fa.gz", "rt") as fh:
    name, buf = None, []
    for line in fh:
        if line[0] == ">":
            if name: flush(name, buf)
            name = line[1:].split()[0]; buf = []
        elif name in need:
            buf.append(line.strip())
    if name: flush(name, buf)

ev["region"] = [f"{c}:{s}-{e}:{st}" for c, s, e, st in zip(ev.chrom, ev.s, ev.e, ev.strand)]
ev["me_seq"] = ev.event.map(seqs)
ev[["event", "region", "me_seq"]].to_csv(f"{RAW}/me_sequences.tsv", sep="\t", index=False)
print("extracted", ev.me_seq.notna().sum(), "of", len(ev))
