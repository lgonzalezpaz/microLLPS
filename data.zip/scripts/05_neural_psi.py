#!/usr/bin/env python3
"""
05_neural_psi.py
Independent quantification of neural regulation for every microexon from the public
PSI matrix of Parada et al. (2026): mean PSI per condition (454 human RNA-seq
conditions). Neural and non-neural (background) conditions follow the authors'
sample sheets. dPSI_neural = median PSI(neural conditions) - median PSI(background).
Output: results/neural_dpsi.tsv
"""
import sys
import numpy as np, pandas as pd

RAW = sys.argv[1] if len(sys.argv) > 1 else "data/raw"
OUT = sys.argv[2] if len(sys.argv) > 2 else "results/neural_dpsi.tsv"
psi = pd.read_csv(f"{RAW}/hg38_PSI_matrix.mean.txt", index_col=0)
neu = set(pd.read_csv(f"{RAW}/human_neuronal_samples.tsv", sep="\t").condition)
bg = set(pd.read_csv(f"{RAW}/human_background_samples.tsv", sep="\t").condition)
ncols = [c for c in psi.columns if c in neu]
bcols = [c for c in psi.columns if c in bg]
ev = pd.read_csv(f"{RAW}/MicEvents.hg38.tab.gz", sep="\t")
plus = ev.strand == "+"
s = np.where(plus, ev.upIntEnd + 1, ev.dnIntEnd + 1)
e = np.where(plus, ev.dnIntStart - 1, ev.upIntStart - 1)
ev["ME"] = [f"{c}_{st}_{a - 1}_{b}" for c, st, a, b in zip(ev.chrom, ev.strand, s, e)]
out = pd.DataFrame(index=ev.event)
out["ME"] = ev.ME.values
P = psi.reindex(ev.ME.values)
out["n_neural"] = P[ncols].notna().sum(axis=1).values
out["n_background"] = P[bcols].notna().sum(axis=1).values
out["psi_neural"] = P[ncols].median(axis=1).values
out["psi_background"] = P[bcols].median(axis=1).values
out["dPSI_neural"] = out.psi_neural - out.psi_background
ok = (out.n_neural >= 5) & (out.n_background >= 5)
out.loc[~ok, "dPSI_neural"] = np.nan
out.reset_index().to_csv(OUT, sep="\t", index=False)
print("neural conds", len(ncols), "background conds", len(bcols),
      "events with dPSI", int(ok.sum()), "of", len(out))
