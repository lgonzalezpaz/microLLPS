#!/usr/bin/env python3
"""
08_orthogonal_llphyscore.py
Orthogonal, locally executable replacement for the FuzDrop / catGRANULE web servers:
LLPhyScore (Cai et al., PNAS 2022), a knowledge-based ML predictor of IDR-driven phase
separation trained on ~500 experimentally validated phase-separating sequences, whose
8 biophysical sub-scores (protein-water, protein-carbon, long-range H-bond, long-range
pi-pi, long/short disorder, kinked-beta, short-range electrostatics) are independent
of the CALVADOS force field used by the dG/c_sat predictor.

For every IDR microexon tested in 02 we score the ME+ and ME- host segment and report
dLLPhy = score(ME+) - score(ME-) (positive = ME increases predicted phase separation).
For the positive controls (CPEB4, EIF4G1, EIF4G3) we also score N_NULL composition-
matched random insertions to obtain a z-score.

Usage: python 08_orthogonal_llphyscore.py <llphyscore_dir> [n_null_controls]
"""
import sys, os, io, contextlib
import numpy as np, pandas as pd

LDIR = sys.argv[1]
N_NULL = int(sys.argv[2]) if len(sys.argv) > 2 else 40
rng = np.random.default_rng(808)
cwd = os.getcwd()
os.chdir(LDIR); sys.path.insert(0, LDIR)
import LLPhyScore_standalone as LL  # noqa: E402
os.chdir(cwd)
DB = os.path.join(LDIR, "ScoreDBs")
AA = "ACDEFGHIKLMNPQRSTVWY"

def score(seqs):
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        g = LL.seqs2grids(seqs, DB)
        r = LL.get_g2w_scores(g, weight=LL.final_models["human+PDB"], features=LL.features)
    return r.set_index("tag")

I = pd.concat([pd.read_csv(f"results/features_shard{i}.tsv", sep="\t") for i in (0, 1)])
I = I[I.status == "ok"]
pairs = pd.read_csv("data/processed/isoform_pairs.tsv", sep="\t").drop_duplicates("event").set_index("event")
seqs, meta = {}, {}
for r in I.itertuples():
    p = pairs.loc[r.event].prot_plus
    s, e, k, L = int(r.idr_start), int(r.idr_end), int(r.aa_pos), int(r.me_aa_len)
    plus = p[s:e]; rel = k - s; minus = plus[:rel] + plus[rel + L:]
    seqs[f"{r.event}|+"] = plus; seqs[f"{r.event}|-"] = minus
    meta[r.event] = (minus, rel, L, r.gene)
    if r.gene in ("CPEB4", "EIF4G1", "EIF4G3"):
        comp = np.array([minus.count(a) for a in AA], float); comp /= comp.sum()
        for j in range(N_NULL):
            pep = "".join(rng.choice(list(AA), size=L, p=comp))
            seqs[f"{r.event}|null{j}"] = minus[:rel] + pep + minus[rel:]
print("scoring", len(seqs), "sequences", flush=True)
# batches of 100 sequences are cached to disk so the step is resumable and can be split
# across workers: WORKER=i NWORKERS=n MAXSEC=s python 08_... (final assembly when all cached)
import time
CACHE = "results/llphy_cache"; os.makedirs(CACHE, exist_ok=True)
keys = list(seqs); B = 100
W, NW = int(os.environ.get("WORKER", 0)), int(os.environ.get("NWORKERS", 1))
T0, MAXSEC = time.time(), float(os.environ.get("MAXSEC", "inf"))
nb = (len(keys) + B - 1) // B
for b in range(nb):
    f = f"{CACHE}/batch_{b:04d}.tsv"
    if b % NW != W or os.path.exists(f): continue
    if time.time() - T0 > MAXSEC: print("paused"); sys.exit(0)
    score({k: seqs[k] for k in keys[b * B:(b + 1) * B]}).to_csv(f, sep="\t")
    print(b + 1, "/", nb, flush=True)
missing = [b for b in range(nb) if not os.path.exists(f"{CACHE}/batch_{b:04d}.tsv")]
if missing: print("waiting for", len(missing), "batches"); sys.exit(0)
R = pd.concat([pd.read_csv(f"{CACHE}/batch_{b:04d}.tsv", sep="\t", index_col=0) for b in range(nb)])
tot = [c for c in R.columns if c.endswith("feature sum")][0]
rows = []
for ev in meta:
    rec = dict(event=ev, gene=meta[ev][3], llphy_plus=R.loc[f"{ev}|+", tot], llphy_minus=R.loc[f"{ev}|-", tot])
    rec["dLLPhy"] = rec["llphy_plus"] - rec["llphy_minus"]
    for c in R.columns:
        if c != tot:
            rec[f"d_{c}"] = R.loc[f"{ev}|+", c] - R.loc[f"{ev}|-", c]
    nulls = [R.loc[k, tot] - rec["llphy_minus"] for k in R.index if k.startswith(f"{ev}|null")]
    if nulls:
        rec["null_mean"], rec["null_sd"] = float(np.mean(nulls)), float(np.std(nulls, ddof=1))
        rec["z_llphy"] = (rec["dLLPhy"] - rec["null_mean"]) / (rec["null_sd"] + 1e-9)
        rec["p_emp_greater"] = (np.sum(np.array(nulls) >= rec["dLLPhy"]) + 1) / (len(nulls) + 1)
    rows.append(rec)
pd.DataFrame(rows).to_csv("results/orthogonal_llphyscore.tsv", sep="\t", index=False)
print(pd.DataFrame(rows).query("gene in ['CPEB4','EIF4G1','EIF4G3']").T)
