#!/usr/bin/env python3
"""
09_switch_permutation.py
High-resolution empirical test for every called switch and the eIF4G controls:
1,000 composition- and position-matched null insertions per microexon (empirical
P floor = 1/1001), plus a scrambled-peptide control (100 permutations of the
microexon's own residues) that tests order- versus composition-dependence.
Usage: python 09_switch_permutation.py <pspred_dir> [n_null] ; reads results/table_S2_...
Output: results/table_S4_switch_permutation.tsv
"""
import sys, os, zlib, warnings
warnings.simplefilter("ignore")
import numpy as np, pandas as pd
PSPRED = sys.argv[1]; N = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
sys.path.insert(0, os.path.join(PSPRED, "scripts_colab"))
import joblib, sequence  # noqa
from predictor import *  # noqa
from predictor import X_from_seq  # noqa
RES = pd.read_csv(os.path.join(PSPRED, "data/residues.csv")).set_index("one")
NU = os.path.join(PSPRED, "models/svr_model_nu.joblib")
FEATS = ["mean_lambda", "faro", "shd", "ncpr", "fcr", "scd", "ah_ij", "nu_svr"]
M = joblib.load(os.path.join(PSPRED, "models/idrome90/mlp/dG/model.joblib"))
AH, LM = sequence.make_ah_intgrl_map(RES), sequence.make_lambda_map(RES)
NM = joblib.load(NU); sequence.load = lambda f: NM if f == NU else joblib.load(f)
def dg(s):
    return float(np.mean(M.predict(X_from_seq(s, FEATS, residues=RES, charge_termini=True, nu_file=NU,
                                              ah_intgrl_map=AH, lambda_map=LM))))
AA = "ACDEFGHIKLMNPQRSTVWY"
I = pd.read_csv("results/table_S2_idr_microexons_switch_calls.tsv", sep="\t")
sel = I[I.switch | I.gene.isin(["EIF4G1", "EIF4G3"])]
P = pd.read_csv("data/processed/isoform_pairs.tsv", sep="\t").drop_duplicates("event").set_index("event")
out_f = "results/table_S4_switch_permutation.tsv"
rows = pd.read_csv(out_f, sep="\t").to_dict("records") if os.path.exists(out_f) else []
done = {r["event"] for r in rows}
for r in sel.itertuples():
    if r.event in done: continue
    rng = np.random.default_rng([9, zlib.crc32(r.event.encode())])
    p = P.loc[r.event].prot_plus; s, e, k, L = int(r.idr_start), int(r.idr_end), int(r.aa_pos), int(r.me_aa_len)
    plus = p[s:e]; rel = k - s; minus = plus[:rel] + plus[rel + L:]
    g0 = dg(minus); obs = dg(plus) - g0
    comp = np.array([minus.count(a) for a in AA], float); comp /= comp.sum()
    null = np.array([dg(minus[:rel] + "".join(rng.choice(list(AA), size=L, p=comp)) + minus[rel:]) - g0 for _ in range(N)])
    scr = np.array([dg(minus[:rel] + "".join(rng.permutation(list(r.me_peptide))) + minus[rel:]) - g0 for _ in range(100)])
    c = null.mean()
    rows.append(dict(event=r.event, gene=r.gene, label=r.label, me_peptide=r.me_peptide, ddG=obs,
                     null_mean=c, null_sd=null.std(ddof=1), z1000=(obs - c) / null.std(ddof=1),
                     p_emp_1000=(np.sum(np.abs(null - c) >= abs(obs - c)) + 1) / (N + 1),
                     scrambled_mean=scr.mean(), scrambled_sd=scr.std(ddof=1),
                     frac_scrambled_as_extreme=float(np.mean(np.abs(scr - c) >= abs(obs - c)))))
    pd.DataFrame(rows).to_csv(out_f, sep="\t", index=False)
    print(r.gene, round(obs, 3), rows[-1]["p_emp_1000"], flush=True)
print("done", len(rows))
