#!/usr/bin/env python3
"""
06_analysis.py  --  statistics, sensitivity analyses, tables and figures.
Usage: python 06_analysis.py <pspred_dir>      (run from repository root)
Outputs: results/stats_summary.json, results/table_*.tsv, figures/Fig*.{svg,png}
"""
import sys, os, json, warnings
warnings.simplefilter("ignore")
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Patch

PSPRED = sys.argv[1]
os.makedirs("figures", exist_ok=True)
rng = np.random.default_rng(42)
S = {}  # summary statistics

# ------------------------------------------------------------------ style
NEU, NON, GRAY, INK, INK2 = "#2a78d6", "#eb6834", "#8a8984", "#0b0b0b", "#52514e"
PRO, ANTI = "#2a78d6", "#e34948"   # diverging poles (pro-condensation / anti)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.linewidth": 0.6,
                     "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2,
                     "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "legend.frameon": False, "svg.fonttype": "none", "pdf.fonttype": 42})
def panel(ax, l):
    ax.text(-0.18, 1.06, l, transform=ax.transAxes, fontsize=11, fontweight="bold", color=INK, va="bottom")
def save(fig, name):
    fig.savefig(f"figures/{name}.svg", bbox_inches="tight")
    fig.savefig(f"figures/{name}.png", dpi=600, bbox_inches="tight")
    fig.savefig(f"figures/{name}.pdf", bbox_inches="tight")
    plt.close(fig)

# ------------------------------------------------------------------ data
F = pd.concat([pd.read_csv(f"results/features_shard{i}.tsv", sep="\t") for i in (0, 1)], ignore_index=True)
pairs = pd.read_csv("data/processed/isoform_pairs.tsv", sep="\t")
dpsi = pd.read_csv("results/neural_dpsi.tsv", sep="\t")[["event", "dPSI_neural"]]
af = pd.read_csv("results/alphafold_plddt.tsv", sep="\t") if os.path.exists("results/alphafold_plddt.tsv") else None
F = F.merge(dpsi, on="event", how="left")
if af is not None:
    F = F.merge(af[["event", "af_found", "af_isoform", "af_plddt_me", "af_plddt_global"]], on="event", how="left")
F["neural"] = F.label.eq("hi")
F["cls"] = np.where(F.neural, "Neural-enhanced", np.where(F.label.eq("nd"), "Not regulated", "Other"))
F.to_csv("results/table_S1_all_microexons.tsv", sep="\t", index=False)

ev = pd.read_csv("data/raw/MicEvents.hg38.tab.gz", sep="\t")
mapped = pairs[pairs.mapped == True]
S["n_events"] = int(len(ev)); S["n_events_by_label"] = ev.label.fillna("na").value_counts().to_dict()
S["n_mapped"] = int(len(mapped)); S["n_mapped_inframe"] = int(mapped.in_frame.sum())
S["n_neural_mapped"] = int((mapped.label == "hi").sum())
S["n_neural_inframe"] = int(((mapped.label == "hi") & mapped.in_frame).sum())
S["frac_inframe_neural"] = float(mapped[mapped.label == "hi"].in_frame.mean())
S["frac_inframe_nd"] = float(mapped[mapped.label == "nd"].in_frame.mean())
t = pd.crosstab(mapped.label == "hi", mapped.in_frame)
S["fisher_inframe_neural_vs_rest"] = stats.fisher_exact(t.values)[1]
S["n_unique_inframe_pairs"] = int(len(F))
S["mode_counts"] = mapped["mode"].value_counts().to_dict()

# label validation with independent dPSI
lab = ev[["event", "label"]].merge(dpsi, on="event")
S["dPSI_by_label_median"] = lab.groupby(lab.label.fillna("na")).dPSI_neural.median().round(3).to_dict()
S["dPSI_by_label_n"] = lab.dropna().groupby(lab.label.fillna("na")).size().to_dict()
S["dPSI_hi_vs_nd_MWU_p"] = stats.mannwhitneyu(lab[lab.label == "hi"].dPSI_neural.dropna(),
                                              lab[lab.label == "nd"].dPSI_neural.dropna()).pvalue

S["status_counts"] = F.status.value_counts().to_dict()
S["ptc_inframe_by_label"] = F[F.status == "no_insertion"].label.value_counts().to_dict()   # in-frame MEs introducing a stop codon
S["ptc_frac_neural_vs_nd"] = {"neural": float((F[F.neural].status == "no_insertion").mean()),
                              "nd": float((F[F.label == "nd"].status == "no_insertion").mean()),
                              "p": float(stats.fisher_exact(pd.crosstab(F[F.neural | (F.label == "nd")].neural,
                                         F[F.neural | (F.label == "nd")].status == "no_insertion").values)[1])}
ok = F[F.status.isin(["ok", "folded_context", "idr_too_short"])].copy()
ok["in_idr"] = ok["in_idr"].astype(bool)
# ---------------------------------------------------------------- 1. structural context
def ctab(df, col):
    a = df[df.neural]; b = df[df.label == "nd"]
    tab = [[a[col].sum(), (~a[col]).sum()], [b[col].sum(), (~b[col]).sum()]]
    o, p = stats.fisher_exact(tab)
    return dict(neural=float(a[col].mean()), nd=float(b[col].mean()), n_neural=len(a), n_nd=len(b), OR=o, p=p)
S["in_idr"] = ctab(ok, "in_idr")
S["in_idr_all"] = float(ok.in_idr.mean())
S["me_disorder_median"] = {"neural": float(ok[ok.neural].me_disorder.median()),
                           "nd": float(ok[ok.label == "nd"].me_disorder.median())}
S["me_disorder_MWU_p"] = stats.mannwhitneyu(ok[ok.neural].me_disorder, ok[ok.label == "nd"].me_disorder).pvalue
# logistic: in_idr ~ neural + ME length + protein disorder fraction
ok["me_len_aa"] = ok.me_aa_len
lr = smf.logit("in_idr ~ neural + me_len_aa + prot_disorder_frac", data=ok.assign(
    in_idr=ok.in_idr.astype(int), neural=ok.neural.astype(int))).fit(disp=0)
S["logit_in_idr"] = {k: dict(OR=float(np.exp(lr.params[k])), lo=float(np.exp(lr.conf_int().loc[k, 0])),
                             hi=float(np.exp(lr.conf_int().loc[k, 1])), p=float(lr.pvalues[k]))
                     for k in lr.params.index if k != "Intercept"}
if af is not None:
    a = ok.dropna(subset=["af_plddt_me"])
    S["af_n"] = int(len(a)); S["af_n_plus"] = int((a.af_isoform == "plus").sum())
    S["af_vs_metapredict_spearman"] = stats.spearmanr(a.af_plddt_me, a.me_disorder)._asdict()
    a2 = a[a.af_isoform == "plus"]
    S["af_plddt_me_median"] = {"in_idr": float(a2[a2.in_idr].af_plddt_me.median()),
                               "folded": float(a2[~a2.in_idr].af_plddt_me.median()),
                               "n_in_idr": int(a2.in_idr.sum()), "n_folded": int((~a2.in_idr).sum())}
    S["af_idr_agreement"] = float(((a2.af_plddt_me < 70) == a2.in_idr).mean()) if len(a2) else None
    S["af_idr_vs_folded_MWU_p"] = stats.mannwhitneyu(a2[a2.in_idr].af_plddt_me, a2[~a2.in_idr].af_plddt_me).pvalue if len(a2) else None

# ---------------------------------------------------------------- 2. switch calling
I = F[F.status == "ok"].copy()
I["p_param"] = 2 * stats.norm.sf(np.abs(I.z_ddG))
I["q"] = multipletests(I.p_param, method="fdr_bh")[1]
I["q_emp"] = multipletests(I.p_emp, method="fdr_bh")[1]
DDG_MIN = 0.2
I["switch"] = (I.q < 0.05) & (I.ddG.abs() >= DDG_MIN)
I["direction"] = np.where(~I.switch, "neutral", np.where(I.ddG < 0, "pro", "anti"))
I["fold_csat"] = np.exp(I.dlogcs)
I.sort_values("z_ddG").to_csv("results/table_S2_idr_microexons_switch_calls.tsv", sep="\t", index=False)
S["n_idr_tested"] = int(len(I)); S["n_idr_neural"] = int(I.neural.sum()); S["n_idr_nd"] = int((I.label == "nd").sum())
S["n_switch"] = int(I.switch.sum()); S["n_switch_pro"] = int((I.direction == "pro").sum())
S["n_switch_anti"] = int((I.direction == "anti").sum())
S["switch"] = ctab(I, "switch")
S["switch_pro_frac"] = {"neural": float((I[I.neural & I.switch].ddG < 0).mean()) if (I.neural & I.switch).any() else None,
                        "nd": float((I[(I.label == "nd") & I.switch].ddG < 0).mean()) if ((I.label == "nd") & I.switch).any() else None}
nps = I[I.neural & I.switch]
S["binom_pro_bias_neural"] = stats.binomtest(int((nps.ddG < 0).sum()), len(nps), 0.5).pvalue if len(nps) else None
S["absz_median"] = {"neural": float(I[I.neural].z_ddG.abs().median()), "nd": float(I[I.label == "nd"].z_ddG.abs().median())}
S["absz_MWU_p"] = stats.mannwhitneyu(I[I.neural].z_ddG.abs(), I[I.label == "nd"].z_ddG.abs(), alternative="greater").pvalue
S["absddG_per_res_median"] = {"neural": float((I[I.neural].ddG.abs() / I[I.neural].me_aa_len).median()),
                              "nd": float((I[I.label == "nd"].ddG.abs() / I[I.label == "nd"].me_aa_len).median())}
S["z_neural_mean"] = float(I[I.neural].z_ddG.mean()); S["z_nd_mean"] = float(I[I.label == "nd"].z_ddG.mean())
S["z_neural_vs_nd_MWU_p_two_sided"] = stats.mannwhitneyu(I[I.neural].z_ddG, I[I.label == "nd"].z_ddG).pvalue
S["z_neural_wilcoxon_vs0_p"] = stats.wilcoxon(I[I.neural].z_ddG).pvalue
lr2 = smf.logit("sw ~ neural + me_aa_len + np.log(idr_len_plus)",
                data=I.assign(sw=I.switch.astype(int), neural=I.neural.astype(int))).fit(disp=0)
S["logit_switch"] = {k: dict(OR=float(np.exp(lr2.params[k])), lo=float(np.exp(lr2.conf_int().loc[k, 0])),
                             hi=float(np.exp(lr2.conf_int().loc[k, 1])), p=float(lr2.pvalues[k]))
                     for k in lr2.params.index if k != "Intercept"}
# paralog-collapsed sensitivity: paralogous microexons (e.g. CPEB2/3/4, RAPGEF2/6) are not
# independent; collapse to gene families (symbol stripped of trailing digits/letters suffix)
import re as _re
I["family"] = I.gene.astype(str).map(lambda g: _re.sub(r"\d+[A-Z]?$", "", g))
fam = I.groupby(["family"]).agg(neural=("neural", "max"), switch=("switch", "max"),
                                nd_only=("label", lambda x: (x == "nd").all())).reset_index()
fa = fam[fam.neural]; fb = fam[fam.nd_only & ~fam.neural]
tab = [[fa.switch.sum(), (~fa.switch).sum()], [fb.switch.sum(), (~fb.switch).sum()]]
S["switch_family_level"] = dict(neural=float(fa.switch.mean()), nd=float(fb.switch.mean()), n_neural=len(fa), n_nd=len(fb),
                                OR=stats.fisher_exact(tab)[0], p=stats.fisher_exact(tab)[1])
S["switch_families"] = I[I.switch].groupby("family").gene.apply(lambda x: sorted(set(x))).to_dict()
# Arg-rich motif: switches whose peptide has >=2 Arg
S["switch_pro_Rge2"] = int(((I.direction == "pro") & (I.me_peptide.str.count("R") >= 2)).sum())
S["Rge2_switch_rate"] = {"Rge2": float(I[I.me_peptide.str.count("R") >= 2].switch.mean()),
                         "n_Rge2": int((I.me_peptide.str.count("R") >= 2).sum()),
                         "other": float(I[I.me_peptide.str.count("R") < 2].switch.mean())}
S["Rge2_by_class"] = {"neural": float((I[I.neural].me_peptide.str.count("R") >= 2).mean()),
                      "nd": float((I[I.label == "nd"].me_peptide.str.count("R") >= 2).mean()),
                      "p": float(stats.fisher_exact(pd.crosstab(I[I.neural | (I.label == "nd")].neural,
                                 I[I.neural | (I.label == "nd")].me_peptide.str.count("R") >= 2).values)[1])}

# host phase-separation competence: the predictor is responsive mainly when the host
# segment is itself near/below the phase boundary (dG(ME-) < 0)
I["competent"] = I.dG_minus < 0
S["frac_competent"] = {"all": float(I.competent.mean()), "neural": float(I[I.neural].competent.mean()),
                       "nd": float(I[I.label == "nd"].competent.mean())}
S["competent_neural_vs_nd"] = ctab(I, "competent")
S["absddG_vs_dGminus_spearman"] = stats.spearmanr(I.dG_minus, I.ddG.abs())._asdict()
C_ = I[I.competent]
S["n_competent"] = int(len(C_))
S["switch_within_competent"] = ctab(C_, "switch") if C_.neural.any() else None
lr3 = smf.logit("sw ~ neural + me_aa_len + np.log(idr_len_plus) + dG_minus",
                data=I.assign(sw=I.switch.astype(int), neural=I.neural.astype(int))).fit(disp=0)
S["logit_switch_adj_competence"] = {k: dict(OR=float(np.exp(lr3.params[k])), lo=float(np.exp(lr3.conf_int().loc[k, 0])),
                                            hi=float(np.exp(lr3.conf_int().loc[k, 1])), p=float(lr3.pvalues[k]))
                                    for k in lr3.params.index if k != "Intercept"}
d = I.dropna(subset=["dPSI_neural"])
S["dPSI_vs_absz_spearman"] = stats.spearmanr(d.dPSI_neural, d.z_ddG.abs())._asdict(); S["dPSI_n"] = int(len(d))
S["dPSI_vs_z_spearman"] = stats.spearmanr(d.dPSI_neural, d.z_ddG)._asdict()

# predictor concordance
S["conc_ddG_dlogcs"] = stats.spearmanr(I.ddG, I.dlogcs)._asdict()
S["conc_ddG_depsMpipi"] = stats.spearmanr(I.ddG, I.deps_Mpipi)._asdict()
S["conc_ddG_depsCALV"] = stats.spearmanr(I.ddG, I.deps_CALV)._asdict()
sw = I[I.switch]
S["sign_agree_Mpipi_switch"] = float((np.sign(sw.ddG) == np.sign(sw.deps_Mpipi)).mean()) if len(sw) else None
S["sign_agree_CALV_switch"] = float((np.sign(sw.ddG) == np.sign(sw.deps_CALV)).mean()) if len(sw) else None
# null calibration: fraction |z|>1.96 expected 5% under null
S["frac_absz_gt196"] = float((I.z_ddG.abs() > 1.96).mean())
S["q_emp_switch_overlap"] = float(((I.q_emp < 0.05) & I.switch).sum() / max(1, I.switch.sum()))
S["n_switch_emp"] = int(((I.q_emp < 0.05) & (I.ddG.abs() >= DDG_MIN)).sum())
S["p_emp_floor"] = 1 / 51
S["switch_at_emp_floor"] = int((I[I.switch].p_emp <= 1 / 51 + 1e-9).sum())
# conservative sensitivity: Student t (49 df) instead of normal for the z-score
I["p_t"] = 2 * stats.t.sf(np.abs(I.z_ddG), df=49); I["q_t"] = multipletests(I.p_t, method="fdr_bh")[1]
I["switch_t"] = (I.q_t < 0.05) & (I.ddG.abs() >= DDG_MIN)
S["n_switch_t49"] = int(I.switch_t.sum())
S["switch_t49"] = ctab(I, "switch_t")

# orthogonal predictor (LLPhyScore; replaces FuzDrop/catGRANULE web servers)
if os.path.exists("results/orthogonal_llphyscore.tsv"):
    LP = pd.read_csv("results/orthogonal_llphyscore.tsv", sep="\t")
    I = I.merge(LP[["event", "llphy_plus", "llphy_minus", "dLLPhy"] + [c for c in LP.columns if c in ("z_llphy", "p_emp_greater")]], on="event", how="left")
    S["llphy_n"] = int(I.dLLPhy.notna().sum())
    S["llphy_vs_negddG_spearman"] = stats.spearmanr(-I.ddG, I.dLLPhy, nan_policy="omit")._asdict()
    S["llphy_vs_negz_spearman"] = stats.spearmanr(-I.z_ddG, I.dLLPhy, nan_policy="omit")._asdict()
    swl = I[I.switch & I.dLLPhy.notna() & (I.dLLPhy != 0)]
    S["llphy_sign_agree_switch"] = float((np.sign(-swl.ddG) == np.sign(swl.dLLPhy)).mean()) if len(swl) else None
    S["llphy_sign_agree_switch_n"] = int(len(swl))
    S["llphy_sign_agree_switch_binom_p"] = float(stats.binomtest(int((np.sign(-swl.ddG) == np.sign(swl.dLLPhy)).sum()), len(swl), 0.5).pvalue) if len(swl) else None
    nsl = I[~I.switch & I.dLLPhy.notna()]
    S["llphy_absdelta_switch_vs_nonswitch"] = dict(switch=float(I[I.switch].dLLPhy.abs().median()), nonswitch=float(nsl.dLLPhy.abs().median()),
        p=float(stats.mannwhitneyu(I[I.switch].dLLPhy.abs().dropna(), nsl.dLLPhy.abs(), alternative="greater").pvalue))
    S["llphy_controls"] = LP[LP.gene.isin(["CPEB4", "EIF4G1", "EIF4G3"])].to_dict("records")

# ---------------------------------------------------------------- 3. validation cases
def case(gene):
    r = I[I.gene == gene]
    if r.empty:
        r2 = F[F.gene == gene]
        return r2[["event", "gene", "label", "me_peptide", "status"]].to_dict("records")
    return r[["event", "gene", "label", "me_peptide", "aa_pos", "idr_start", "idr_end", "ddG", "dlogcs",
              "fold_csat", "deps_Mpipi", "deps_CALV", "z_ddG", "q", "switch", "direction"]].to_dict("records")
S["case_CPEB4"] = case("CPEB4"); S["case_EIF4G1"] = case("EIF4G1"); S["case_EIF4G3"] = case("EIF4G3")
S["case_SRC"] = F[F.gene == "SRC"][["event", "label", "me_peptide", "status", "me_disorder"]].to_dict("records")
cp = I[I.gene == "CPEB4"]
if len(cp):
    S["CPEB4_rank_z_among_neural"] = int((I[I.neural].z_ddG < cp.z_ddG.iloc[0]).sum() + 1)
    S["CPEB4_percentile_ddG_all"] = float((I.ddG < cp.ddG.iloc[0]).mean() * 100)

# ---------------------------------------------------------------- 4. composition
AA = "ACDEFGHIKLMNPQRSTVWY"
def counts(seqs):
    c = pd.Series(0, index=list(AA), dtype=float)
    for s in seqs:
        for a in str(s):
            if a in c.index: c[a] += 1
    return c
grpA = I[I.neural].me_peptide; grpB = I[I.label == "nd"].me_peptide
host = pd.read_csv("data/processed/isoform_pairs.tsv", sep="\t")
cA, cB = counts(grpA), counts(grpB)
comp = []
for a in AA:
    tab = [[cA[a], cA.sum() - cA[a]], [cB[a], cB.sum() - cB[a]]]
    o, p = stats.fisher_exact(tab)
    se = np.sqrt(sum(1 / (x + 0.5) for row in tab for x in row))
    lo_ = np.log2(((cA[a] + .5) * (cB.sum() - cB[a] + .5)) / ((cA.sum() - cA[a] + .5) * (cB[a] + .5)))
    comp.append(dict(aa=a, neural_frac=cA[a] / cA.sum(), nd_frac=cB[a] / cB.sum(), log2OR=lo_,
                     ci=1.96 * se / np.log(2), p=p))
comp = pd.DataFrame(comp); comp["q"] = multipletests(comp.p, method="fdr_bh")[1]
comp.to_csv("results/table_S3_me_composition_neural_vs_nd.tsv", sep="\t", index=False)
S["composition_sig"] = comp[comp.q < 0.05][["aa", "log2OR", "q"]].round(4).to_dict("records")
# stickers vs ddG
def frac(s, set_):
    s = str(s); return sum(c in set_ for c in s) / max(1, len(s))
I["f_arom"] = I.me_peptide.map(lambda s: frac(s, "FYW")); I["f_R"] = I.me_peptide.map(lambda s: frac(s, "R"))
I["f_acid"] = I.me_peptide.map(lambda s: frac(s, "DE")); I["f_K"] = I.me_peptide.map(lambda s: frac(s, "K"))
I["f_SPT"] = I.me_peptide.map(lambda s: frac(s, "STP"))
mreg = smf.ols("z_ddG ~ f_arom + f_R + f_K + f_acid + f_SPT + me_aa_len", data=I).fit()
S["ols_z_on_composition"] = {k: dict(beta=float(mreg.params[k]), p=float(mreg.pvalues[k])) for k in mreg.params.index}
S["ols_z_on_composition_R2"] = float(mreg.rsquared)

# ---------------------------------------------------------------- 5. gene-set enrichment
cd = pd.read_csv("data/raw/annot/cdcode_human_proteins.tsv", sep="\t")
cdg = set(cd[cd.biomolecular_condensate_count > 0].gene_name.dropna().str.upper())
sf = pd.read_csv("data/raw/annot/sfari_genes.csv")
sfg = set(sf["gene-symbol"].str.upper()); sfg12 = set(sf[sf["gene-score"].isin([1, 2])]["gene-symbol"].str.upper())
I["G"] = I.gene.str.upper()
def gene_fisher(mask, gset, universe):
    g1 = set(universe[mask].G); g0 = set(universe[~mask].G) - g1
    a, b = len(g1 & gset), len(g1 - gset); c, d_ = len(g0 & gset), len(g0 - gset)
    o, p = stats.fisher_exact([[a, b], [c, d_]])
    return dict(in_set_switch=a, n_switch_genes=a + b, in_set_bg=c, n_bg_genes=c + d_, OR=o, p=p)
S["enrich_switch_CDCODE"] = gene_fisher(I.switch.values, cdg, I)
S["enrich_switch_SFARI"] = gene_fisher(I.switch.values, sfg, I)
S["enrich_switch_SFARI_score12"] = gene_fisher(I.switch.values, sfg12, I)
S["enrich_neuralswitch_SFARI"] = gene_fisher((I.switch & I.neural).values, sfg, I)
S["enrich_neuralswitch_CDCODE"] = gene_fisher((I.switch & I.neural).values, cdg, I)
# all mapped in-frame MEs: IDR hosts in condensate proteome
ok["G"] = ok.gene.str.upper()
S["enrich_idrME_CDCODE"] = gene_fisher(ok.in_idr.values, cdg, ok)

# ---------------------------------------------------------------- 6. sensitivity: local window
sys.path.insert(0, os.path.join(PSPRED, "scripts_colab"))
import joblib  # noqa
from predictor import *  # noqa
from predictor import X_from_seq  # noqa
RES = pd.read_csv(os.path.join(PSPRED, "data/residues.csv")).set_index("one")
NU = os.path.join(PSPRED, "models/svr_model_nu.joblib")
FEATS = ["mean_lambda", "faro", "shd", "ncpr", "fcr", "scd", "ah_ij", "nu_svr"]
M_DG = joblib.load(os.path.join(PSPRED, "models/idrome90/mlp/dG/model.joblib"))
import sequence  # noqa: E402  (pspred module; maps cached as in 02_llps_features.py)
AH_MAP, LAMBDA_MAP = sequence.make_ah_intgrl_map(RES), sequence.make_lambda_map(RES)
_NU_MODEL = joblib.load(NU); sequence.load = lambda f: _NU_MODEL if f == NU else joblib.load(f)
def dg(s):
    return float(np.mean(M_DG.predict(X_from_seq(s, FEATS, residues=RES, charge_termini=True, nu_file=NU,
                                                 ah_intgrl_map=AH_MAP, lambda_map=LAMBDA_MAP))))
P = pairs.set_index("event")
def window_ddg(W=None):
    out = []
    for r in I.itertuples():
        pp = P.loc[r.event]
        if isinstance(pp, pd.DataFrame): pp = pp.iloc[0]
        s, k, L = pp.prot_plus, int(r.aa_pos), int(r.me_aa_len)
        if W is None: a, b = int(r.idr_full_start), int(r.idr_full_end)      # uncapped IDR
        else: a, b = max(int(r.idr_full_start), k - W), min(int(r.idr_full_end), k + L + W)
        plus = s[a:b]; minus = plus[:k - a] + plus[k - a + L:]
        try: out.append(dg(plus) - dg(minus))
        except Exception: out.append(np.nan)
    return out
I["ddG_fullIDR"] = window_ddg(None); I["ddG_win50"] = window_ddg(50)
for c in ("ddG_fullIDR", "ddG_win50"):
    S[f"sens_{c}_spearman"] = stats.spearmanr(I.ddG, I[c], nan_policy="omit")._asdict()
    S[f"sens_{c}_sign_agree_switch"] = float((np.sign(I[I.switch].ddG) == np.sign(I[I.switch][c])).mean())
# sensitivity: exclude very short MEs (<4 aa)
J = I[I.me_aa_len >= 4]
S["sens_len4_switch"] = ctab(J, "switch")
# sensitivity: effect-size threshold
S["sens_threshold"] = {str(t): ctab(I.assign(sw=(I.q < 0.05) & (I.ddG.abs() >= t)), "sw") for t in (0.0, 0.1, 0.2, 0.5)}
# prior-predictive: pooled null (composition-matched random insertions)
S["prior_pred_null_sd_median"] = float(I.null_sd.median())
S["prior_pred_obs_absddG_median"] = float(I.ddG.abs().median())
I.to_csv("results/table_S2_idr_microexons_switch_calls.tsv", sep="\t", index=False)

# benchmark summary
B = json.load(open("results/benchmark/benchmark_summary.json"))
# benchmark extension: raw AUROC, autonomy strata, length-adjusted logistic model
bpp = pd.read_csv("results/benchmark/benchmark_phasepro_vs_proteome.tsv", sep="\t")
ppj = json.load(open("data/raw/annot/phasepro.json"))
auto = {e["accession"]: (e["partner_dep"] == "N" and e["rna_dep"] == "N") for e in ppj.values()}
bpp["driver"] = (bpp.set == "PhaSePro_driver_IDR").astype(int)
bpp["autonomous"] = bpp.id.map(auto).fillna(False).astype(bool)
bgd = bpp[bpp.driver == 0]
def au(sub):
    return float(stats.mannwhitneyu(-sub.dG, -bgd.dG).statistic / (len(sub) * len(bgd)))
for nm, sub in (("raw_all", bpp[bpp.driver == 1]), ("raw_autonomous", bpp[(bpp.driver == 1) & bpp.autonomous]),
                ("raw_partner_dependent", bpp[(bpp.driver == 1) & ~bpp.autonomous])):
    bs = [au(sub.sample(len(sub), replace=True, random_state=i)) for i in range(1000)]
    B[f"auroc_{nm}"] = dict(n=int(len(sub)), auroc=au(sub), lo=float(np.percentile(bs, 2.5)), hi=float(np.percentile(bs, 97.5)),
                             p=float(stats.mannwhitneyu(-sub.dG, -bgd.dG, alternative="greater").pvalue))
bpp["negdG"] = -bpp.dG; bpp["loglen"] = np.log(bpp.len)
for nm, dat in (("all", bpp), ("autonomous", bpp[(bpp.driver == 0) | bpp.autonomous])):
    m = smf.logit("driver ~ negdG + loglen", data=dat).fit(disp=0)
    B[f"logit_len_adjusted_{nm}"] = dict(OR_per_kT=float(np.exp(m.params.negdG)), lo=float(np.exp(m.conf_int().loc["negdG", 0])),
                                         hi=float(np.exp(m.conf_int().loc["negdG", 1])), p=float(m.pvalues.negdG))
S["benchmark"] = B
json.dump(S, open("results/stats_summary.json", "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))

# ================================================================== FIGURES
# Figure 1: workflow + funnel
fig = plt.figure(figsize=(7.2, 3.0))
ax = fig.add_axes([0, 0, 0.62, 1]); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 10)
steps = [("Microexon catalogue", f"{S['n_events']:,} human events (3–27 nt)\nneural labels + 454-condition PSI"),
         ("Isoform reconstruction", f"Ensembl 115 CDS; {S['n_mapped']:,} mapped\n{S['n_unique_inframe_pairs']:,} unique in-frame ME±"),
         ("Structural context", "metapredict v3 disorder + IDR calls\nAlphaFold DB v6 pLDDT"),
         ("Condensation physics", "ΔG, c_sat (CALVADOS-trained MLP)\nε homotypic (FINCHES Mpipi-GG / CALVADOS2)"),
         ("Switch statistics", "composition- and position-matched\nnull insertions, z-score, BH-FDR"),
         ("Validation", "CPEB4 & EIF4G1/3 (experimental); LLPhyScore;\nexperimental c_sat, PhaSePro, CD-CODE, SFARI")]
for i, (h, t) in enumerate(steps):
    y = 9.2 - i * 1.55
    ax.add_patch(FancyBboxPatch((0.2, y - 1.15), 9.4, 1.25, boxstyle="round,pad=0.02,rounding_size=0.15",
                                fc="#f2f6fc" if i % 2 == 0 else "#fcf3ee", ec=INK2, lw=0.5))
    ax.text(0.45, y - 0.35, h, fontsize=8, fontweight="bold", color=INK, va="center")
    ax.text(4.0, y - 0.52, t, fontsize=6.6, color=INK2, va="center")
    if i < len(steps) - 1:
        ax.annotate("", xy=(1.0, y - 1.25), xytext=(1.0, y - 1.13), arrowprops=dict(arrowstyle="-|>", color=INK2, lw=0.6))
ax.text(-0.02, 1.0, "a", transform=ax.transAxes, fontsize=11, fontweight="bold")
ax2 = fig.add_axes([0.72, 0.15, 0.27, 0.75])
vals = [S["n_events"], S["n_mapped"], S["n_mapped_inframe"], S["n_unique_inframe_pairs"], int(ok.in_idr.sum()), S["n_idr_tested"], S["n_switch"]]
labs = ["catalogued", "mapped to CDS", "in-frame", "unique pairs", "in IDR", "ΔG tested", "switches (q<0.05)"]
ax2.barh(range(len(vals))[::-1], vals, color=NEU, height=0.62)
for i, v in enumerate(vals):
    ax2.text(v * 1.15, len(vals) - 1 - i, f"{v:,}", va="center", fontsize=6.5, color=INK)
ax2.set_yticks(range(len(vals))[::-1]); ax2.set_yticklabels(labs, fontsize=6.8)
ax2.set_xscale("log"); ax2.set_xlabel("Microexons (n, log scale)"); ax2.set_xlim(0.8, max(vals) * 4); panel(ax2, "b")
save(fig, "Fig1_workflow")

# Figure 2: predictor validation
bexp = pd.read_csv("results/benchmark/benchmark_exp_csat.tsv", sep="\t")
bpp = pd.read_csv("results/benchmark/benchmark_phasepro_vs_proteome.tsv", sep="\t")
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.8))
ax = axs[0]
ax.scatter(bexp.logcdil_mgml_exp, bexp.logcs_pred_local, s=18, c=NEU, edgecolor="white", lw=0.4)
lims = [min(bexp.logcdil_mgml_exp.min(), bexp.logcs_pred_local.min()) - .3, max(bexp.logcdil_mgml_exp.max(), bexp.logcs_pred_local.max()) + .3]
ax.plot(lims, lims, color=GRAY, lw=0.6, ls="--"); ax.set_xlim(lims); ax.set_ylim(lims)
ax.set_xlabel("Experimental ln c$_{sat}$ (mg mL$^{-1}$)"); ax.set_ylabel("Predicted ln c$_{sat}$ (mg mL$^{-1}$)")
ax.text(0.04, 0.93, f"Spearman ρ = {B['exp_spearman']:.2f}\nP = {B['exp_spearman_p']:.1e}; n = {B['exp_n']}", transform=ax.transAxes, fontsize=6.8, va="top")
panel(ax, "a")
ax = axs[1]
bg_ = np.sort(bpp[bpp.set == "proteome_IDR"].dG.values); dr_ = np.sort(bpp[bpp.set == "PhaSePro_driver_IDR"].dG.values)
au_ = np.sort(bpp[(bpp.set == "PhaSePro_driver_IDR") & bpp.id.map(auto).fillna(False)].dG.values)
ax.step(bg_, np.arange(1, len(bg_) + 1) / len(bg_), color=GRAY, lw=1.2, where="post", label=f"Proteome IDRs (n={len(bg_):,})")
ax.step(dr_, np.arange(1, len(dr_) + 1) / len(dr_), color=NEU, lw=1.2, where="post", label=f"PhaSePro driver IDRs (n={len(dr_)})")
ax.step(au_, np.arange(1, len(au_) + 1) / len(au_), color=NEU, lw=1.0, ls="--", where="post", label=f"  autonomous drivers (n={len(au_)})")
ax.set_xlim(-8, 2); ax.set_ylabel("Cumulative fraction")
ax.axvline(0, color=INK2, lw=0.5, ls=":")
ax.set_xlabel("Predicted ΔG$_{trans}$ (k$_B$T)")
ax.text(0.02, 0.97, f"AUROC all = {B['auroc_raw_all']['auroc']:.2f}\n"
        f"autonomous = {B['auroc_raw_autonomous']['auroc']:.2f}\nlength-matched = {B['auroc']:.2f}",
        transform=ax.transAxes, fontsize=6.4, va="top")
ax.legend(fontsize=6.0, loc="lower right"); panel(ax, "b")
fig.tight_layout(); save(fig, "Fig2_predictor_validation")

# Figure 3: structural context
fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.6))
ax = axs[0]
grp = [("Neural-enhanced", ok[ok.neural]), ("Not regulated", ok[ok.label == "nd"]), ("Other", ok[~ok.neural & (ok.label != "nd")])]
for i, (n, g) in enumerate(grp):
    p = g.in_idr.mean(); n_ = len(g); z_ = 1.96
    cen = (p + z_**2 / (2 * n_)) / (1 + z_**2 / n_); hw = z_ * np.sqrt(p * (1 - p) / n_ + z_**2 / (4 * n_**2)) / (1 + z_**2 / n_)
    ax.bar(i, p * 100, color=[NEU, NON, GRAY][i], width=0.6)
    ax.errorbar(i, p * 100, yerr=[[(p - (cen - hw)) * 100], [((cen + hw) - p) * 100]], color=INK, lw=0.7, capsize=2)
    ax.text(i, (cen + hw) * 100 + 2, f"{p*100:.0f}%\nn={n_}", ha="center", fontsize=6.2)
ax.set_xticks(range(3)); ax.set_xticklabels([g[0].replace("-", "-\n").replace(" ", "\n") for g in grp], fontsize=6.6)
ax.set_ylabel("Microexons in IDR (%)"); ax.set_ylim(0, 110)
ax.text(0.5, 0.97, f"Fisher P = {S['in_idr']['p']:.1e}", transform=ax.transAxes, ha="center", fontsize=6.6, va="top")
panel(ax, "a")
ax = axs[1]
for i, (n, g) in enumerate(grp[:2]):
    v = g.me_disorder.dropna()
    parts = ax.violinplot(v, positions=[i], widths=0.7, showextrema=False)
    for pc in parts["bodies"]: pc.set_facecolor([NEU, NON][i]); pc.set_alpha(0.6); pc.set_edgecolor("none")
    ax.boxplot(v, positions=[i], widths=0.12, showfliers=False, medianprops=dict(color=INK, lw=0.8),
               boxprops=dict(lw=0.6), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6))
ax.axhline(0.5, color=GRAY, lw=0.5, ls=":")
ax.set_xticks([0, 1]); ax.set_xticklabels(["Neural-\nenhanced", "Not\nregulated"], fontsize=6.6)
ax.set_ylabel("Mean disorder of ME residues"); panel(ax, "b")
ax.text(0.5, 1.0, f"MWU P = {S['me_disorder_MWU_p']:.1e}", transform=ax.transAxes, ha="center", fontsize=6.6, va="bottom")
ax = axs[2]
if af is not None:
    a = ok.dropna(subset=["af_plddt_me"])
    ax.scatter(a.me_disorder, a.af_plddt_me, s=5, c=np.where(a.in_idr, NEU, NON), alpha=0.6, lw=0)
    ax.axhline(70, color=GRAY, lw=0.5, ls=":"); ax.axvline(0.5, color=GRAY, lw=0.5, ls=":")
    ax.set_xlabel("metapredict disorder (ME)"); ax.set_ylabel("AlphaFold pLDDT (ME or junction)")
    rho = S["af_vs_metapredict_spearman"]["statistic"]
    ax.text(0.97, 0.97, f"ρ = {rho:.2f}\nn = {S['af_n']}", transform=ax.transAxes, ha="right", va="top", fontsize=6.6)
    ax.scatter([], [], c=NEU, s=8, label="IDR context"); ax.scatter([], [], c=NON, s=8, label="Folded context")
    ax.legend(fontsize=6, loc="lower left")
panel(ax, "c")
fig.tight_layout(); save(fig, "Fig3_structural_context")

# Figure 4: switch landscape
fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.7), gridspec_kw=dict(width_ratios=[1.35, 1, 1]))
ax = axs[0]
nsw = I[~I.switch]
ax.scatter(nsw.ddG, -np.log10(nsw.q), s=4, c=GRAY, alpha=0.35, lw=0)
for d_, c_ in (("pro", PRO), ("anti", ANTI)):
    g = I[I.direction == d_]
    ax.scatter(g.ddG, -np.log10(g.q), s=np.where(g.neural, 14, 6), c=c_, alpha=0.85, lw=0.3,
               edgecolor=np.where(g.neural, INK, "none"))
ax.axhline(-np.log10(0.05), color=GRAY, lw=0.5, ls=":")
for x in (-DDG_MIN, DDG_MIN): ax.axvline(x, color=GRAY, lw=0.5, ls=":")
for gname in ("CPEB4", "EIF4G1", "EIF4G3"):
    g = I[I.gene == gname]
    for r in g.itertuples():
        ax.annotate(gname, (r.ddG, -np.log10(r.q)), xytext=(6, 4), textcoords="offset points", fontsize=6.5,
                    color=INK, arrowprops=dict(arrowstyle="-", lw=0.4, color=INK2))
ax.set_xlabel("ΔΔG$_{trans}$ = ΔG(ME+) − ΔG(ME−) (k$_B$T)"); ax.set_ylabel("−log$_{10}$ q (FDR)")
ax.legend(handles=[Patch(color=PRO, label=f"pro-condensation switch (n={S['n_switch_pro']})"),
                   Patch(color=ANTI, label=f"anti-condensation switch (n={S['n_switch_anti']})"),
                   Patch(color=GRAY, label="not significant")], fontsize=5.8, loc="upper left")
xl = np.nanpercentile(np.abs(I.ddG), 99.7) * 1.15; ax.set_xlim(-xl, xl)
panel(ax, "a")
ax = axs[1]
bins = np.linspace(-8, 8, 41)
ax.hist(I[I.label == "nd"].z_ddG.clip(-8, 8), bins=bins, density=True, color=NON, alpha=0.55, label="Not regulated")
ax.hist(I[I.neural].z_ddG.clip(-8, 8), bins=bins, density=True, color=NEU, alpha=0.6, label="Neural-enhanced")
xx = np.linspace(-8, 8, 200); ax.plot(xx, stats.norm.pdf(xx), color=INK, lw=0.7, ls="--", label="Null N(0,1)")
ax.set_xlabel("Switch z-score (vs matched null)"); ax.set_ylabel("Density"); ax.legend(fontsize=6)
panel(ax, "b")
ax = axs[2]
cats = [("Neural-enhanced", I[I.neural]), ("Not regulated", I[I.label == "nd"]), ("Other", I[~I.neural & (I.label != "nd")])]
for i, (n, g) in enumerate(cats):
    pr = (g.direction == "pro").mean() * 100; an = (g.direction == "anti").mean() * 100
    ax.bar(i, pr, color=PRO, width=0.6); ax.bar(i, an, bottom=pr, color=ANTI, width=0.6)
    ax.text(i, pr + an + 1.5, f"{pr+an:.0f}%\nn={len(g)}", ha="center", fontsize=6.2)
ax.set_xticks(range(3)); ax.set_xticklabels(["Neural-\nenhanced", "Not\nregulated", "Other"], fontsize=6.6)
ax.set_ylabel("IDR microexons called switches (%)")
ax.legend(handles=[Patch(color=PRO, label="pro-condensation"), Patch(color=ANTI, label="anti-condensation")], fontsize=6, loc="upper right")
ax.set_ylim(0, max(55, ax.get_ylim()[1] * 1.15)); panel(ax, "c")
fig.tight_layout(); save(fig, "Fig4_switch_landscape")

# Figure 5: CPEB4 case study
import metapredict as meta
cpp = pairs[(pairs.gene == "CPEB4") & (pairs.label == "hi")].iloc[0]
cps = I[I.gene == "CPEB4"].iloc[0]
fig = plt.figure(figsize=(7.2, 4.6))
ax = fig.add_axes([0.07, 0.62, 0.9, 0.32])
dplus = meta.predict_disorder(cpp.prot_plus); x = np.arange(1, len(dplus) + 1)
ax.plot(x, dplus, color=NEU, lw=1.0)
ax.fill_between(x, 0, dplus, color=NEU, alpha=0.12)
k, L = int(cps.aa_pos), int(cps.me_aa_len)
ax.axvspan(k + 0.5, k + L + 0.5, color=ANTI, alpha=0.35)
ax.text(k + L / 2, 1.04, f"ME: {cps.me_peptide}", ha="center", fontsize=7, color=INK)
# His cluster = 24-aa window with most His in NTD
win = 24; hc = int(np.argmax([cpp.prot_plus[i:i + win].count("H") for i in range(0, int(cps.idr_end) - win)]))
ax.axvspan(hc + 1, hc + win, color=GRAY, alpha=0.3); ax.text(hc + win / 2, 1.04, "His cluster", ha="center", fontsize=7, color=INK2)
ax.axvspan(int(cps.idr_start) + 1, int(cps.idr_end), ymin=0, ymax=0.04, color=INK2)
ax.text((cps.idr_start + cps.idr_end) / 2, 0.07, f"analysed host segment (residues {int(cps.idr_start)+1}–{int(cps.idr_end)}) within N-terminal IDR {int(cps.idr_full_start)+1}–{int(cps.idr_full_end)}", ha="center", fontsize=6.6, color=INK2)
ax.set_xlim(1, len(dplus)); ax.set_ylim(0, 1.12); ax.set_ylabel("Disorder"); ax.set_xlabel("CPEB4 residue (neuronal isoform, ENST00000265085)")
panel(ax, "a")
# null distribution re-generated for display (same procedure, independent seed)
idr = cpp.prot_plus[int(cps.idr_start):int(cps.idr_end)]; rel = k - int(cps.idr_start)
idm = idr[:rel] + idr[rel + L:]
comp_ = np.array([idm.count(a) for a in AA], float); comp_ /= comp_.sum()
g0 = dg(idm)
nulls = np.array([dg(idm[:rel] + "".join(rng.choice(list(AA), size=L, p=comp_)) + idm[rel:]) - g0 for _ in range(500)])
# scrambled-ME control (same residues, shuffled order) and Arg->Lys / Arg->Ala variants
scr = np.array([dg(idm[:rel] + "".join(rng.permutation(list(cps.me_peptide))) + idm[rel:]) - g0 for _ in range(100)])
RK = cps.me_peptide.replace("R", "K"); RA = cps.me_peptide.replace("R", "A"); TYA = cps.me_peptide.replace("Y", "A")
var = {"ME (WT)": cps.ddG, "R→K": dg(idm[:rel] + RK + idm[rel:]) - g0, "R→A": dg(idm[:rel] + RA + idm[rel:]) - g0,
       "Y→A": dg(idm[:rel] + TYA + idm[rel:]) - g0, "2×ME": dg(idr[:rel + L] + cps.me_peptide + idr[rel + L:]) - g0}
S["CPEB4_null500_mean"] = float(nulls.mean()); S["CPEB4_null500_sd"] = float(nulls.std(ddof=1))
S["CPEB4_null500_emp_p"] = float((np.sum(nulls <= cps.ddG) + 1) / 501)
S["CPEB4_scrambled_mean"] = float(scr.mean()); S["CPEB4_scrambled_sd"] = float(scr.std(ddof=1))
S["CPEB4_variants_ddG"] = {k_: float(v) for k_, v in var.items()}
S["CPEB4_null500_shapiro_p"] = float(stats.shapiro(nulls).pvalue)
ax = fig.add_axes([0.07, 0.1, 0.38, 0.36])
ax.hist(nulls, bins=30, color=GRAY, alpha=0.6, density=True, label="random insertions (n=500)")
ax.axvline(cps.ddG, color=ANTI, lw=1.4, label=f"CPEB4 ME: {cps.ddG:.2f} k$_B$T")
ax.set_xlabel("ΔΔG$_{trans}$ (k$_B$T)"); ax.set_ylabel("Density"); ax.legend(fontsize=6.2, loc="upper left")
ax.text(0.03, 0.72, f"z = {(cps.ddG-nulls.mean())/nulls.std(ddof=1):.1f}\nempirical P = {S['CPEB4_null500_emp_p']:.3f}", transform=ax.transAxes, ha="left", fontsize=6.6)
panel(ax, "b")
ax = fig.add_axes([0.58, 0.1, 0.39, 0.36])
names = list(var) + ["scrambled"]; vals_ = list(var.values()) + [scr.mean()]
errs = [0] * len(var) + [scr.std(ddof=1)]
cols = [PRO if v < 0 else ANTI for v in vals_]
ax.barh(range(len(names))[::-1], vals_, color=cols, height=0.6, xerr=errs, error_kw=dict(lw=0.6, ecolor=INK))
ax.set_yticks(range(len(names))[::-1]); ax.set_yticklabels(names, fontsize=6.8)
ax.axvline(0, color=INK2, lw=0.5); ax.set_xlabel("ΔΔG$_{trans}$ vs Δ4 isoform (k$_B$T)")
panel(ax, "c")
save(fig, "Fig5_CPEB4_validation")

# Figure 6: composition and determinants
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.8), gridspec_kw=dict(width_ratios=[1.6, 1]))
ax = axs[0]
cs = comp.sort_values("log2OR")
cols = [NEU if (q < 0.05 and v > 0) else (NON if (q < 0.05 and v < 0) else GRAY) for v, q in zip(cs.log2OR, cs.q)]
ax.bar(range(20), cs.log2OR, yerr=cs.ci, color=cols, width=0.7, error_kw=dict(lw=0.5, ecolor=INK2))
ax.set_xticks(range(20)); ax.set_xticklabels(cs.aa); ax.axhline(0, color=INK2, lw=0.5)
ax.set_ylabel("log$_2$ OR (neural-enhanced vs not regulated)"); ax.set_xlabel("Residue in IDR microexon peptides")
panel(ax, "a")
ax = axs[1]
coef = pd.DataFrame(S["ols_z_on_composition"]).T.drop(index=["Intercept", "me_aa_len"])
ci_ = mreg.conf_int().loc[coef.index]
nm = {"f_arom": "aromatic (F/Y/W)", "f_R": "Arg", "f_K": "Lys", "f_acid": "Asp/Glu", "f_SPT": "Ser/Pro/Thr"}
y = np.arange(len(coef))[::-1]
ax.errorbar(coef.beta, y, xerr=[coef.beta - ci_[0], ci_[1] - coef.beta], fmt="o", ms=4, color=INK, lw=0.7)
ax.axvline(0, color=GRAY, lw=0.5, ls=":"); ax.set_yticks(y); ax.set_yticklabels([nm[i] for i in coef.index])
ax.set_xlabel("β on switch z (OLS, per unit fraction)"); panel(ax, "b")
fig.tight_layout(); save(fig, "Fig6_composition")

# Figure 7: biology
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.7))
ax = axs[0]
d = I.dropna(subset=["dPSI_neural"])
ax.scatter(d.dPSI_neural, d.z_ddG.clip(-15, 15), s=8, c=np.where(d.neural, NEU, NON), alpha=0.7, lw=0)
ax.axhline(0, color=GRAY, lw=0.5, ls=":")
ax.set_xlabel("ΔPSI neural − non-neural"); ax.set_ylabel("Switch z-score")
ax.set_title(f"ρ(ΔPSI, |z|) = {S['dPSI_vs_absz_spearman']['statistic']:.2f}, P = {S['dPSI_vs_absz_spearman']['pvalue']:.2f}; n = {S['dPSI_n']}",
             fontsize=6.6, color=INK2)
ax.scatter([], [], c=NEU, s=8, label="neural-enhanced label"); ax.scatter([], [], c=NON, s=8, label="other labels")
ax.legend(fontsize=6, loc="lower left")
panel(ax, "a")
ax = axs[1]
E_ = [("CD-CODE condensate\nproteome", S["enrich_switch_CDCODE"]), ("SFARI (all)", S["enrich_switch_SFARI"]),
      ("SFARI score 1–2", S["enrich_switch_SFARI_score12"])]
for i, (n, e) in enumerate(E_):
    a_, b_ = e["in_set_switch"], e["n_switch_genes"]; c_, d2 = e["in_set_bg"], e["n_bg_genes"]
    ax.bar(i - 0.17, a_ / max(1, b_) * 100, width=0.32, color=NEU)
    ax.bar(i + 0.17, c_ / max(1, d2) * 100, width=0.32, color=GRAY)
    ax.text(i, max(a_ / max(1, b_), c_ / max(1, d2)) * 100 + 3, f"OR {e['OR']:.2f}\nP = {e['p']:.2g}", ha="center", fontsize=6)
ax.set_xticks(range(3)); ax.set_xticklabels([n for n, _ in E_], fontsize=6.6)
ax.set_ylabel("Host genes in set (%)")
ax.legend(handles=[Patch(color=NEU, label="switch hosts"), Patch(color=GRAY, label="non-switch IDR-ME hosts")], fontsize=6, loc="upper right"); ax.set_ylim(0, 100); panel(ax, "b")
fig.tight_layout(); save(fig, "Fig7_biology")

json.dump(S, open("results/stats_summary.json", "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
# high-resolution permutation results (09_switch_permutation.py), if available
if os.path.exists("results/table_S4_switch_permutation.tsv"):
    S4 = pd.read_csv("results/table_S4_switch_permutation.tsv", sep="\t")
    S["perm1000"] = S4[["gene", "me_peptide", "ddG", "z1000", "p_emp_1000", "scrambled_mean", "frac_scrambled_as_extreme"]].round(5).to_dict("records")
    sw4 = S4[S4.event.isin(I[I.switch].event)]
    S["perm1000_n_switch_p_lt_0.01"] = int((sw4.p_emp_1000 < 0.01).sum()); S["perm1000_n_switch"] = int(len(sw4))
    S["perm1000_n_order_dependent"] = int((sw4.frac_scrambled_as_extreme < 0.05).sum())
    json.dump(S, open("results/stats_summary.json", "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
# main-text Table 1: top switches
top = I[I.switch].copy()
top["abs_z"] = top.z_ddG.abs()
t1 = top.sort_values("ddG")[["gene", "label", "me_peptide", "aa_pos", "idr_len_plus", "dG_minus", "ddG",
                                "fold_csat", "deps_CALV", "z_ddG", "q", "direction"]]
if os.path.exists("results/table_S4_switch_permutation.tsv"):
    t1 = t1.merge(S4[["gene", "me_peptide", "p_emp_1000"]], on=["gene", "me_peptide"], how="left")
t1.to_csv("results/table1_top_switches.tsv", sep="\t", index=False)
print(json.dumps({k: S[k] for k in ["n_idr_tested", "n_switch", "n_switch_pro", "n_switch_anti", "switch", "in_idr"]}, indent=1, default=str))
