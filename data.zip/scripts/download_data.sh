#!/usr/bin/env bash
# Download every public input used in the study into data/raw (≈1.1 GB).
set -euo pipefail
mkdir -p data/raw/annot ext
cd ext
[ -d mrc ]    || git clone --depth 1 https://github.com/geparada/microexon-regulatory-code.git mrc
[ -d pspred ] || git clone --depth 1 https://github.com/kull-centre/_2024_buelow_pspred.git pspred
[ -d finches ] || git clone --depth 1 https://github.com/idptools/finches.git finches
[ -d llphyscore ] || { git clone --depth 1 https://github.com/julie-forman-kay-lab/LLPhyScore.git llphyscore && (cd llphyscore/standalone_package && tar -xf LLPhyScore-standalone-*.tar.gz); }
cd ..
cp ext/mrc/microexon-code/resources/inputs/wt/MicEvents.hg38.tab.gz data/raw/
cp ext/mrc/VariantPredictions/data/microexon_metadata.hg38.csv data/raw/
cp ext/mrc/microexon-code/resources/novel_microexon_hg38/hg38_PSI_matrix.mean.txt data/raw/
cp ext/mrc/DataAnalysis/Input/human_neuronal_samples.tsv ext/mrc/DataAnalysis/Input/human_background_samples.tsv data/raw/
E=https://ftp.ensembl.org/pub/release-115
cd data/raw
curl -sSO $E/gtf/homo_sapiens/Homo_sapiens.GRCh38.115.gtf.gz
curl -sSO $E/fasta/homo_sapiens/cds/Homo_sapiens.GRCh38.cds.all.fa.gz
curl -sSO $E/tsv/homo_sapiens/Homo_sapiens.GRCh38.115.uniprot.tsv.gz
curl -sSO $E/fasta/homo_sapiens/dna/Homo_sapiens.GRCh38.dna.primary_assembly.fa.gz
cd annot
curl -sS https://phasepro.elte.hu/download_full.json -o phasepro.json
curl -sSL "https://gene.sfari.org/wp-content/themes/sfari-gene/utilities/download-csv.php?api-endpoint=genes" -o sfari_genes.csv
python - <<'EOF'
import json, urllib.request, pandas as pd
rows, page = [], 1
while True:
    d = json.load(urllib.request.urlopen(f"https://cd-code.org/api/proteins?page={page}&size=1000", timeout=120))
    rows += d["data"]
    if not d["data"] or len(rows) >= d["count"]: break
    page += 1
df = pd.DataFrame(rows)
df[df.species_taxon_id == 9606][["uniprot_id", "gene_name", "biomolecular_condensate_count",
    "synthetic_condensate_count"]].to_csv("cdcode_human_proteins.tsv", sep="\t", index=False)
EOF
