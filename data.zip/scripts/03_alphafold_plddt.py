#!/usr/bin/env python3
"""
03_alphafold_plddt.py
Retrieve AlphaFold DB (v6) per-residue pLDDT for the UniProt entries mapped to each
host transcript and locate the microexon (ME) peptide in the AlphaFold model sequence.
If the AlphaFold sequence contains the ME (+ isoform), report pLDDT of ME residues;
if it is the skipping isoform, report pLDDT of the 5 residues flanking the junction.

Usage: python 03_alphafold_plddt.py <isoform_pairs.tsv> <ensembl_uniprot.tsv.gz> <out.tsv>
"""
import sys, json, time, urllib.request
import numpy as np, pandas as pd

pairs_f, xref_f, out_f = sys.argv[1:4]
pairs = pd.read_csv(pairs_f, sep="\t")
pairs = pairs[(pairs.mapped == True) & (pairs.in_frame == True)]
x = pd.read_csv(xref_f, sep="\t")
x = x[x.db_name.isin(["Uniprot/SWISSPROT", "Uniprot/SPTREMBL"])]
x["rank"] = (x.db_name == "Uniprot/SWISSPROT").astype(int)
tx2acc = (x.sort_values("rank", ascending=False).groupby("transcript_stable_id")["xref"]
          .apply(lambda s: list(dict.fromkeys(s))).to_dict())
gene2acc = (x[x.db_name == "Uniprot/SWISSPROT"].groupby("gene_stable_id")["xref"]
            .apply(lambda s: list(dict.fromkeys(s))).to_dict())

def get_json(url):
    for a in range(4):
        try:
            return json.load(urllib.request.urlopen(url, timeout=60))
        except Exception:
            time.sleep(1.5 * (a + 1))
    return None

cache = {}
def af_entries(acc):
    if acc not in cache:
        cache[acc] = get_json(f"https://alphafold.ebi.ac.uk/api/prediction/{acc}") or []
    return cache[acc]

plddt_cache = {}
def plddt(url):
    if url not in plddt_cache:
        d = get_json(url)
        plddt_cache[url] = np.asarray(d["confidenceScore"], float) if d else None
    return plddt_cache[url]

from concurrent.futures import ThreadPoolExecutor
# prefetch AlphaFold entries and pLDDT documents concurrently (I/O bound)
accs_all = set()
for r in pairs.itertuples():
    accs_all.update(tx2acc.get(r.transcript, []) + gene2acc.get(r.gene_id, []))
with ThreadPoolExecutor(12) as ex:
    list(ex.map(af_entries, sorted(accs_all)))
urls = set()
for r in pairs.itertuples():
    for acc in tx2acc.get(r.transcript, []) + gene2acc.get(r.gene_id, []):
        for ent in cache.get(acc, []):
            s_ = ent.get("sequence", "")
            if s_ in (r.prot_plus, r.prot_minus) or (str(r.me_peptide) in s_ and len(s_) == r.len_plus):
                urls.add(ent["plddtDocUrl"])
with ThreadPoolExecutor(12) as ex:
    list(ex.map(plddt, sorted(urls)))
print("prefetched", len(accs_all), "accessions,", len(urls), "pLDDT files", flush=True)

rows = []
for r in pairs.itertuples():
    pep = str(r.me_peptide); k = int(r.aa_pos)
    accs = tx2acc.get(r.transcript, []) + gene2acc.get(r.gene_id, [])
    rec = dict(event=r.event, transcript=r.transcript, gene=r.gene)
    found = False
    for acc in dict.fromkeys(accs):
        for ent in af_entries(acc):
            s = ent.get("sequence", "")
            if s == r.prot_plus or (pep and pep in s and len(s) == r.len_plus):
                pl = plddt(ent["plddtDocUrl"])
                if pl is None: continue
                i = s.find(pep, max(0, k - 3)) if s != r.prot_plus else k
                rec.update(af_entry=ent["entryId"], af_isoform="plus",
                           af_plddt_me=float(pl[i:i + len(pep)].mean()),
                           af_plddt_global=float(pl.mean())); found = True; break
            if s == r.prot_minus:
                pl = plddt(ent["plddtDocUrl"])
                if pl is None: continue
                lo, hi = max(0, k - 5), min(len(pl), k + 5)
                rec.update(af_entry=ent["entryId"], af_isoform="minus",
                           af_plddt_me=float(pl[lo:hi].mean()),
                           af_plddt_global=float(pl.mean())); found = True; break
        if found: break
    rec["af_found"] = found
    rows.append(rec)
    if len(rows) % 50 == 0:
        print(len(rows), flush=True); pd.DataFrame(rows).to_csv(out_f, sep="\t", index=False)
pd.DataFrame(rows).to_csv(out_f, sep="\t", index=False)
print("done", len(rows), "found", sum(r["af_found"] for r in rows))
