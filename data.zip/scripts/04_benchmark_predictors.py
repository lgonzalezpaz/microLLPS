#!/usr/bin/env python3
"""
04_benchmark_predictors.py
Independent checks that the locally executed predictors behave as published:
 (a) experimental saturation concentrations of 35 hnRNPA1/A1-LCD-family variants
     (von Buelow et al. 2025 revision set) vs predicted log c_sat;
 (b) discrimination of experimentally validated LLPS-driving IDRs (PhaSePro) from
     length-matched IDRs of the human MANE Select proteome (AUROC, bootstrap 95% CI);
 (c) the proteome-wide IDR dG distribution used as context in the main analysis.
Usage: python 04_benchmark_predictors.py <pspred_dir> <raw_dir> <out_dir> [n_bg] [seed]
"""
import sys, os, gzip, re, json, warnings
warnings.simplefilter("ignore")
import numpy as np, pandas as pd
from scipy.stats import spearmanr, pearsonr, mannwhitneyu

PSPRED, RAW, OUT = sys.argv[1:4]
N_BG = int(sys.argv[4]) if len(sys.argv) > 4 else 3000
rng = np.random.default_rng(int(sys.argv[5]) if len(sys.argv) > 5 else 7)
os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.join(PSPRED, "scripts_colab"))
import joblib  # noqa
from predictor import *  # noqa
from predictor import X_from_seq  # noqa
import metapredict as meta  # noqa

RES = pd.read_csv(os.path.join(PSPRED, "data/residues.csv")).set_index("one")
NU = os.path.join(PSPRED, "models/svr_model_nu.joblib")
FEATS = ["mean_lambda", "faro", "shd", "ncpr", "fcr", "scd", "ah_ij", "nu_svr"]
M_DG = joblib.load(os.path.join(PSPRED, "models/idrome90/mlp/dG/model.joblib"))
M_CS = joblib.load(os.path.join(PSPRED, "models/idrome90/mlp/logcdil_mgml/model.joblib"))
AA20 = set("ACDEFGHIKLMNPQRSTVWY")

def pred(seq):
    X = X_from_seq(seq, FEATS, residues=RES, charge_termini=True, nu_file=NU)
    return float(np.mean(M_DG.predict(X))), float(np.mean(M_CS.predict(X)))

# (a) experimental c_sat
exp = pd.read_csv(os.path.join(PSPRED, "data_revision/df_csat_exp_fixed.csv"))
exp = exp[exp.logcdil_mgml_exp.notna()].copy()
exp["logcs_pred_local"] = [pred(s)[1] for s in exp.fasta]
rs = spearmanr(exp.logcs_pred_local, exp.logcdil_mgml_exp)
rp = pearsonr(exp.logcs_pred_local, exp.logcdil_mgml_exp)
exp[["name", "fasta", "logcdil_mgml_exp", "logcs_pred_local"]].to_csv(f"{OUT}/benchmark_exp_csat.tsv", sep="\t", index=False)

# (b) PhaSePro drivers vs proteome IDRs
def translate_cds(nt):
    code = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
    b = "TCAG"; tab = {a + c + d: code[16 * i + 4 * j + k] for i, a in enumerate(b)
                     for j, c in enumerate(b) for k, d in enumerate(b)}
    p = []
    for i in range(0, len(nt) - 2, 3):
        aa = tab.get(nt[i:i + 3], "X")
        if aa == "*": break
        p.append(aa)
    return "".join(p)

mane = set()
with gzip.open(f"{RAW}/Homo_sapiens.GRCh38.115.gtf.gz", "rt") as fh:
    for line in fh:
        if '\ttranscript\t' in line and 'tag "MANE_Select"' in line:
            mane.add(line.split('transcript_id "')[1].split('"')[0])
prot = {}
with gzip.open(f"{RAW}/Homo_sapiens.GRCh38.cds.all.fa.gz", "rt") as fh:
    tid, buf = None, []
    for line in fh:
        if line[0] == ">":
            if tid in mane: prot[tid] = translate_cds("".join(buf))
            tid = line[1:].split()[0].split(".")[0]; buf = []
        else:
            buf.append(line.strip())
    if tid in mane: prot[tid] = translate_cds("".join(buf))
ids = list(prot)
rng.shuffle(ids)
bg = []
for tid in ids:
    s = prot[tid]
    if len(s) < 30 or not set(s) <= AA20: continue
    for a, b in meta.predict_disorder_domains(s).disordered_domain_boundaries:
        if 30 <= b - a <= 800:
            bg.append((tid, a, b, s[a:b]))
    if len(bg) >= N_BG * 2: break
bg = pd.DataFrame(bg, columns=["id", "start", "end", "seq"]).sample(n=min(N_BG, len(bg)), random_state=1)
bg["dG"], bg["logcs"] = zip(*[pred(s) for s in bg.seq])
bg["set"] = "proteome_IDR"

pp = json.load(open(f"{RAW}/annot/phasepro.json"))
drv = []
for e in pp.values():
    s = e["sequence"]
    if not set(s) <= AA20: continue
    regs = []
    for blk in str(e["boundaries"]).split(","):
        m = re.match(r"\s*(\d+)\s*-\s*(\d+)", blk)
        if m: regs.append((int(m.group(1)) - 1, int(m.group(2))))
    for a, b in meta.predict_disorder_domains(s).disordered_domain_boundaries:
        if b - a < 30 or b - a > 800: continue
        if any(min(b, y) - max(a, x) >= 0.5 * (b - a) for x, y in regs):
            drv.append((e["accession"], a, b, s[a:b], e["organism"]))
drv = pd.DataFrame(drv, columns=["id", "start", "end", "seq", "organism"]).drop_duplicates("seq")
drv["dG"], drv["logcs"] = zip(*[pred(s) for s in drv.seq])
drv["set"] = "PhaSePro_driver_IDR"
allr = pd.concat([bg, drv], ignore_index=True)
allr["len"] = allr.seq.str.len()
allr.drop(columns=["seq"]).to_csv(f"{OUT}/benchmark_phasepro_vs_proteome.tsv", sep="\t", index=False)
bg[["id", "start", "end", "seq", "dG", "logcs"]].to_csv(f"{OUT}/proteome_idr_background.tsv", sep="\t", index=False)

def auroc(pos, neg):
    u = mannwhitneyu(pos, neg, alternative="two-sided").statistic
    return u / (len(pos) * len(neg))

# length-matched AUROC (score = -dG; higher = more PS-prone)
bins = np.quantile(allr.len, np.linspace(0, 1, 6))
allr["lbin"] = np.digitize(allr.len, bins[1:-1])
pos = -allr.loc[allr.set == "PhaSePro_driver_IDR", "dG"].values
neg_all = allr[allr.set == "proteome_IDR"]
# reweight background to driver length distribution by stratified resampling
w = allr[allr.set == "PhaSePro_driver_IDR"].lbin.value_counts(normalize=True)
neg = np.concatenate([-neg_all[neg_all.lbin == b].dG.sample(n=int(round(w[b] * len(neg_all))), replace=True,
                                                            random_state=b).values for b in w.index])
A = auroc(pos, neg)
boot = [auroc(rng.choice(pos, len(pos)), rng.choice(neg, len(neg))) for _ in range(2000)]
lo, hi = np.percentile(boot, [2.5, 97.5])
res = dict(exp_n=len(exp), exp_spearman=rs.statistic, exp_spearman_p=rs.pvalue,
           exp_pearson=rp.statistic, exp_pearson_p=rp.pvalue,
           n_driver=len(pos), n_background=len(neg_all), auroc=A, auroc_lo=lo, auroc_hi=hi,
           p_mwu=mannwhitneyu(pos, neg, alternative="greater").pvalue,
           bg_median_dG=float(neg_all.dG.median()), driver_median_dG=float(np.median(-pos)),
           bg_frac_dG_neg=float((neg_all.dG < 0).mean()))
json.dump(res, open(f"{OUT}/benchmark_summary.json", "w"), indent=1)
print(json.dumps(res, indent=1))
