#!/usr/bin/env python3
"""
02_llps_features.py
For every in-frame microexon (ME) isoform pair, compute:
  * residue-level disorder (metapredict v3) and predicted pLDDT at the ME;
  * whether the ME lies in an intrinsically disordered region (IDR);
  * for ME located in IDRs: phase-separation free energy (dG, kT) and saturation
    concentration (log c_sat, mg/mL) of the host IDR with (+) and without (-) the ME
    using the CALVADOS-trained predictor of von Buelow et al. (PNAS 2025), and the
    homotypic mean-field interaction parameter epsilon (FINCHES; Mpipi-GG and CALVADOS2);
  * host segment = metapredict IDR containing the ME, clipped to +/-400 residues;
  * a sequence-specific null: n_null random peptides of identical length, drawn from
    the host IDR's own amino-acid composition and inserted at the ME position.

Usage: python 02_llps_features.py <isoform_pairs.tsv> <pspred_dir> <out.tsv> [n_null] [seed]
"""
import sys, os, warnings
warnings.simplefilter("ignore")
import numpy as np, pandas as pd

pairs_f, PSPRED, out_f = sys.argv[1], sys.argv[2], sys.argv[3]
N_NULL = int(sys.argv[4]) if len(sys.argv) > 4 else 100
SEED = int(sys.argv[5]) if len(sys.argv) > 5 else 20261020
WIN = 400
import zlib

sys.path.insert(0, os.path.join(PSPRED, "scripts_colab"))
import joblib, sequence                      # noqa: E402
from predictor import *                      # noqa: F401,F403,E402  (needed to unpickle models)
from predictor import X_from_seq             # noqa: E402
import metapredict as meta                   # noqa: E402
from finches import Mpipi_frontend, CALVADOS_frontend  # noqa: E402

RES = pd.read_csv(os.path.join(PSPRED, "data/residues.csv")).set_index("one")
NU = os.path.join(PSPRED, "models/svr_model_nu.joblib")
FEATS = ["mean_lambda", "faro", "shd", "ncpr", "fcr", "scd", "ah_ij", "nu_svr"]
M_DG = joblib.load(os.path.join(PSPRED, "models/idrome90/mlp/dG/model.joblib"))
M_CS = joblib.load(os.path.join(PSPRED, "models/idrome90/mlp/logcdil_mgml/model.joblib"))
MPIPI, CALV = Mpipi_frontend(), CALVADOS_frontend()
AA20 = "ACDEFGHIKLMNPQRSTVWY"

# sequence-independent pair maps and the nu-SVR model are computed/loaded once and reused
# (numerically identical to recomputing them inside every call)
AH_MAP = sequence.make_ah_intgrl_map(RES)
LAMBDA_MAP = sequence.make_lambda_map(RES)
_NU_MODEL = joblib.load(NU)
sequence.load = lambda f: _NU_MODEL if f == NU else joblib.load(f)
# dictionary look-ups replace per-residue pandas indexing (same summation order -> identical values)
_LAM, _MW = RES.lambdas.to_dict(), RES.MW.to_dict()
def _mean_lambda(seq, residues):
    t = 0.
    for x in seq: t += _LAM[x]
    return t / len(seq)
def _mw(fasta, residues=[]):
    m = 0.
    for x in "".join(fasta): m += _MW[x]
    return m
sequence.calc_mean_lambda, sequence.calc_mw = _mean_lambda, _mw

def ps_predict(seq):
    X = X_from_seq(seq, FEATS, residues=RES, charge_termini=True, nu_file=NU,
                   ah_intgrl_map=AH_MAP, lambda_map=LAMBDA_MAP)
    return float(np.mean(M_DG.predict(X))), float(np.mean(M_CS.predict(X)))

def eps(seq):
    return float(MPIPI.epsilon(seq, seq)), float(CALV.epsilon(seq, seq))

def clean(s):
    return "".join(c for c in s if c in AA20)

pairs = pd.read_csv(pairs_f, sep="\t")
pairs = pairs[(pairs.mapped == True) & (pairs.in_frame == True)].copy()
# one row per unique protein-level change (identical events reported by several IDs)
pairs = pairs.drop_duplicates(subset=["transcript", "aa_pos", "me_peptide"])
# resumable: events already written to out_f are kept and skipped
rows, done = [], set()
if os.path.exists(out_f):
    prev = pd.read_csv(out_f, sep="\t"); rows = prev.to_dict("records"); done = set(prev.event)
import time
T0, MAXSEC = time.time(), float(os.environ.get("MAXSEC", "inf"))   # optional wall-clock budget
for n, r in enumerate(pairs.itertuples(), 1):
    if r.event in done:
        continue
    if time.time() - T0 > MAXSEC:
        pd.DataFrame(rows).to_csv(out_f, sep="\t", index=False)
        print(f"paused at {len(rows)}/{len(pairs)}"); sys.exit(0)
    # per-event random stream: results do not depend on processing order or resumption
    rng = np.random.default_rng([SEED, zlib.crc32(r.event.encode())])
    p_plus, p_minus = clean(r.prot_plus), clean(r.prot_minus)
    k = int(r.aa_pos)
    ins = p_plus[k:len(p_plus) - (len(p_minus) - k)] if len(p_plus) >= len(p_minus) else ""
    L = len(ins)
    rec = dict(event=r.event, gene=r.gene, label=r.label, transcript=r.transcript,
               aa_pos=k, me_peptide=ins, me_aa_len=L, prot_len=len(p_plus))
    if L == 0 or len(p_plus) < 30:
        rec["status"] = "no_insertion"; rows.append(rec); continue
    dis = np.asarray(meta.predict_disorder(p_plus))
    plddt = np.asarray(meta.predict_pLDDT(p_plus))
    rec["me_disorder"] = float(dis[k:k + L].mean())
    rec["me_pLDDT_pred"] = float(plddt[k:k + L].mean())
    rec["prot_disorder_frac"] = float((dis >= 0.5).mean())
    # IDR containing the ME (metapredict domains, >=50 % ME residue overlap)
    dom = meta.predict_disorder_domains(p_plus)
    host = None
    for s, e in dom.disordered_domain_boundaries:
        ov = max(0, min(e, k + L) - max(s, k))
        if ov >= 0.5 * L:
            host = (s, e); break
    rec["in_idr"] = host is not None
    if host is None:
        rec["status"] = "folded_context"; rows.append(rec); continue
    s, e = host
    rec.update(idr_full_start=s, idr_full_end=e)
    # local host segment: IDR clipped to +/- WIN residues around the ME (bounds the O(N^2)
    # sequence-charge/hydropathy decoration terms; sensitivity to full-IDR in 06_analysis.py)
    s, e = max(s, k - WIN), min(e, k + L + WIN)
    idr_plus = p_plus[s:e]
    rel = k - s
    idr_minus = idr_plus[:rel] + idr_plus[rel + L:]
    rec.update(idr_start=s, idr_end=e, idr_len_plus=len(idr_plus))
    if len(idr_minus) < 20:
        rec["status"] = "idr_too_short"; rows.append(rec); continue
    try:
        dg_p, cs_p = ps_predict(idr_plus); dg_m, cs_m = ps_predict(idr_minus)
        em_p, ec_p = eps(idr_plus); em_m, ec_m = eps(idr_minus)
    except Exception as exc:
        rec["status"] = f"error:{type(exc).__name__}"; rows.append(rec); continue
    rec.update(dG_plus=dg_p, dG_minus=dg_m, ddG=dg_p - dg_m,
               logcs_plus=cs_p, logcs_minus=cs_m, dlogcs=cs_p - cs_m,
               epsMpipi_plus=em_p, epsMpipi_minus=em_m, deps_Mpipi=em_p - em_m,
               epsCALV_plus=ec_p, epsCALV_minus=ec_m, deps_CALV=ec_p - ec_m)
    # composition-matched, position-matched null insertions
    comp = np.array([idr_minus.count(a) for a in AA20], float); comp /= comp.sum()
    null = []
    for _ in range(N_NULL):
        pep = "".join(rng.choice(list(AA20), size=L, p=comp))
        null.append(ps_predict(idr_minus[:rel] + pep + idr_minus[rel:])[0] - dg_m)
    null = np.asarray(null)
    rec["null_mean"], rec["null_sd"] = float(null.mean()), float(null.std(ddof=1))
    rec["z_ddG"] = (rec["ddG"] - null.mean()) / (null.std(ddof=1) + 1e-9)
    rec["p_emp"] = float((np.sum(np.abs(null - null.mean()) >= abs(rec["ddG"] - null.mean())) + 1) / (N_NULL + 1))
    rec["status"] = "ok"
    rows.append(rec)
    if n % 25 == 0:
        print(f"{n}/{len(pairs)}", flush=True)
        pd.DataFrame(rows).to_csv(out_f, sep="\t", index=False)

pd.DataFrame(rows).to_csv(out_f, sep="\t", index=False)
print("done", len(rows))
