#!/usr/bin/env python3
"""
01_build_isoforms.py
Map human microexons (Parada et al. 2026 catalogue, VastDB-derived events) onto
Ensembl protein-coding transcripts and build paired protein isoforms that differ
only by microexon inclusion (ME+) or skipping (ME-).

Inputs  (see README for download commands)
  data/raw/MicEvents.hg38.tab.gz              microexon events with neural labels
  data/raw/microexon_metadata.hg38.csv        microexon sequences (known + novel)
  data/raw/Homo_sapiens.GRCh38.115.gtf.gz     Ensembl 115 annotation
  data/raw/Homo_sapiens.GRCh38.cds.all.fa.gz  Ensembl 115 CDS sequences
Output
  data/processed/isoform_pairs.tsv
"""
import gzip, re, sys, os
from collections import defaultdict
import pandas as pd

RAW = sys.argv[1] if len(sys.argv) > 1 else "data/raw"
OUT = sys.argv[2] if len(sys.argv) > 2 else "data/processed"
os.makedirs(OUT, exist_ok=True)

CODON = {}
bases = "TCAG"
aas = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
i = 0
for a in bases:
    for b in bases:
        for c in bases:
            CODON[a + b + c] = aas[i]; i += 1

def translate(nt):
    p = []
    for k in range(0, len(nt) - 2, 3):
        aa = CODON.get(nt[k:k + 3], "X")
        if aa == "*":
            break
        p.append(aa)
    return "".join(p)

def revcomp(s):
    return s[::-1].translate(str.maketrans("ACGTN", "TGCAN"))

# ---------------------------------------------------------------- events
ev = pd.read_csv(f"{RAW}/MicEvents.hg38.tab.gz", sep="\t", dtype={"label": str})
ev["label"] = ev["label"].fillna("na")
ev["chrom"] = ev["chrom"].str.replace("chr", "", regex=False)
plus = ev.strand == "+"
ev["me_start"] = 0; ev["me_end"] = 0
ev.loc[plus, "me_start"] = ev.loc[plus, "upIntEnd"] + 1
ev.loc[plus, "me_end"] = ev.loc[plus, "dnIntStart"] - 1
ev.loc[~plus, "me_start"] = ev.loc[~plus, "dnIntEnd"] + 1
ev.loc[~plus, "me_end"] = ev.loc[~plus, "upIntStart"] - 1
# skipping junction (genomic intron when the microexon is skipped)
ev.loc[plus, "skip_s"] = ev.loc[plus, "upIntStart"]; ev.loc[plus, "skip_e"] = ev.loc[plus, "dnIntEnd"]
ev.loc[~plus, "skip_s"] = ev.loc[~plus, "dnIntStart"]; ev.loc[~plus, "skip_e"] = ev.loc[~plus, "upIntEnd"]
for c in ["me_start", "me_end", "skip_s", "skip_e"]:
    ev[c] = ev[c].astype(int)
ev["me_len"] = ev.me_end - ev.me_start + 1
assert (ev.me_len == ev.lengthDiff).all(), "coordinate convention mismatch"

meta = pd.read_csv(f"{RAW}/microexon_metadata.hg38.csv")
seq_by_event = dict(zip(meta.event, meta.microexon_seq))
# genome-derived sequences (00_fetch_me_sequences.py) take precedence when available
if os.path.exists(f"{RAW}/me_sequences.tsv"):
    gs = pd.read_csv(f"{RAW}/me_sequences.tsv", sep="\t").dropna(subset=["me_seq"])
    seq_by_event.update(dict(zip(gs.event, gs.me_seq)))

# ---------------------------------------------------------------- GTF
tx_cds = defaultdict(list)     # tid -> [(start,end)]
tx_exon = defaultdict(list)
tx_info = {}
attr_re = re.compile(r'(\S+) "([^"]*)"')
with gzip.open(f"{RAW}/Homo_sapiens.GRCh38.115.gtf.gz", "rt") as fh:
    for line in fh:
        if line[0] == "#":
            continue
        f = line.rstrip("\n").split("\t")
        if f[2] not in ("CDS", "exon"):
            continue
        if 'transcript_biotype "protein_coding"' not in f[8]:
            continue
        a = f[8]
        tid = a.split('transcript_id "')[1].split('"')[0]
        if f[2] == "CDS":
            tx_cds[tid].append((int(f[3]), int(f[4])))
        else:
            tx_exon[tid].append((int(f[3]), int(f[4])))
        if tid not in tx_info:
            tags = re.findall(r'tag "([^"]+)"', a)
            tx_info[tid] = dict(chrom=f[0], strand=f[6],
                                gene=(a.split('gene_name "')[1].split('"')[0] if 'gene_name "' in a else ""),
                                gene_id=a.split('gene_id "')[1].split('"')[0],
                                tags=set(tags))
        else:
            for t in re.findall(r'tag "([^"]+)"', a):
                tx_info[tid]["tags"].add(t)

# CDS sequences
cds_seq = {}
with gzip.open(f"{RAW}/Homo_sapiens.GRCh38.cds.all.fa.gz", "rt") as fh:
    tid, buf = None, []
    for line in fh:
        if line[0] == ">":
            if tid: cds_seq[tid] = "".join(buf)
            tid = line[1:].split()[0].split(".")[0]; buf = []
        else:
            buf.append(line.strip())
    if tid: cds_seq[tid] = "".join(buf)

# index transcripts by chromosome for quick lookup
by_chrom = defaultdict(list)
for tid, segs in tx_cds.items():
    info = tx_info[tid]
    if "cds_start_NF" in info["tags"] or "cds_end_NF" in info["tags"]:
        continue
    if tid not in cds_seq:
        continue
    lo = min(s for s, e in segs); hi = max(e for s, e in segs)
    by_chrom[info["chrom"]].append((lo, hi, tid))

def ordered(segs, strand):
    return sorted(segs, key=lambda x: x[0], reverse=(strand == "-"))

def genomic_to_cds_offset(segs, strand, pos):
    """0-based offset of genomic position pos within the spliced CDS, or None."""
    off = 0
    for s, e in ordered(segs, strand):
        if s <= pos <= e:
            return off + (pos - s if strand == "+" else e - pos)
        off += e - s + 1
    return None

def rank(tid):
    t = tx_info[tid]["tags"]
    return (("MANE_Select" in t), ("Ensembl_canonical" in t), len(cds_seq[tid]))

rows = []
for r in ev.itertuples():
    cand_inc, cand_skip = [], []
    for lo, hi, tid in by_chrom.get(r.chrom, []):
        if hi < r.skip_s or lo > r.skip_e or tx_info[tid]["strand"] != r.strand:
            continue
        segs = tx_cds[tid]
        if (r.me_start, r.me_end) in segs:                      # ME annotated as coding exon
            cand_inc.append(tid); continue
        # skipping: two consecutive CDS segments joined across the skip junction
        ss = sorted(segs)
        for (s1, e1), (s2, e2) in zip(ss[:-1], ss[1:]):
            if e1 + 1 == r.skip_s and s2 - 1 == r.skip_e:
                cand_skip.append(tid); break
    mode, tid = None, None
    if cand_inc:
        tid = max(cand_inc, key=rank); mode = "inclusion_annotated"
    elif cand_skip:
        tid = max(cand_skip, key=rank); mode = "skipping_annotated"
    if tid is None:
        rows.append(dict(event=r.event, mapped=False)); continue
    segs, strand, cds = tx_cds[tid], r.strand, cds_seq[tid]
    if mode == "inclusion_annotated":
        first = r.me_start if strand == "+" else r.me_end
        o = genomic_to_cds_offset(segs, strand, first)
        me_nt = cds[o:o + r.me_len]
        cds_plus, cds_minus = cds, cds[:o] + cds[o + r.me_len:]
    else:
        me_nt = seq_by_event.get(r.event)
        if not isinstance(me_nt, str) or len(me_nt) != r.me_len:
            rows.append(dict(event=r.event, mapped=False, note="no_me_sequence")); continue
        # last coding base before the junction
        last = r.skip_s - 1 if strand == "+" else r.skip_e + 1
        o = genomic_to_cds_offset(segs, strand, last) + 1
        cds_minus, cds_plus = cds, cds[:o] + me_nt + cds[o:]
    p_plus, p_minus = translate(cds_plus), translate(cds_minus)
    # aligned difference: common prefix / suffix
    k = 0
    while k < min(len(p_plus), len(p_minus)) and p_plus[k] == p_minus[k]:
        k += 1
    j = 0
    while (j < min(len(p_plus), len(p_minus)) - k and
           p_plus[-1 - j] == p_minus[-1 - j]):
        j += 1
    ins = p_plus[k:len(p_plus) - j]
    rows.append(dict(event=r.event, mapped=True, mode=mode, transcript=tid,
                     gene=tx_info[tid]["gene"], gene_id=tx_info[tid]["gene_id"],
                     mane=("MANE_Select" in tx_info[tid]["tags"]),
                     chrom=r.chrom, strand=strand, me_start=r.me_start, me_end=r.me_end,
                     me_len=r.me_len, label=r.label, in_frame=(r.me_len % 3 == 0),
                     me_nt=me_nt, cds_offset=o, aa_pos=k, me_peptide=ins,
                     len_plus=len(p_plus), len_minus=len(p_minus),
                     prot_plus=p_plus, prot_minus=p_minus))

out = pd.DataFrame(rows)
out.to_csv(f"{OUT}/isoform_pairs.tsv", sep="\t", index=False)
m = out[out.mapped == True]
print("events:", len(ev), "mapped:", len(m), "in-frame:", int(m.in_frame.sum()))
print(m.groupby(["label", "in_frame"]).size())
