// Build the Word manuscript from manuscript.md (light markup, see below).
// Markup: "# " title; "## " level-1 heading; "### " level-2 heading;
// "AUTHORS: ", "AFFIL: ", "CORR: ", "KEYWORDS: " title-page lines;
// "ABSTRACT: " abstract paragraph; "EQ: <equation> | (n)" numbered equation;
// "FIG: <png path> | <caption>" figure with caption; "TAB: <tsv path> | <caption> | <ncols>" table;
// "REF: " reference-list entry; inline *italic*, **bold**, ^superscript^, ~subscript~.
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, ImageRun, Table, TableRow,
  TableCell, WidthType, BorderStyle, Header, PageNumber, LineNumberRestartFormat, ShadingType,
} = require("docx");

const SRC = process.argv[2] || "manuscript/manuscript.md";
const OUT = process.argv[3] || "manuscript/manuscript.docx";
const FONT = "Times New Roman";
const lines = fs.readFileSync(SRC, "utf8").split("\n");

function runs(text, base = {}) {
  // tokenise inline markup
  const out = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\^[^^]+\^|~[^~]+~)/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), font: FONT, ...base }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, font: FONT, ...base }));
    else if (t.startsWith("*")) out.push(new TextRun({ text: t.slice(1, -1), italics: true, font: FONT, ...base }));
    else if (t.startsWith("^")) out.push(new TextRun({ text: t.slice(1, -1), superScript: true, font: FONT, ...base }));
    else out.push(new TextRun({ text: t.slice(1, -1), subScript: true, font: FONT, ...base }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), font: FONT, ...base }));
  return out;
}
const body = (text, opt = {}) => new Paragraph({
  children: runs(text, { size: opt.size || 24 }), spacing: { line: opt.line || 480, after: opt.after ?? 240 },
  alignment: opt.align || AlignmentType.LEFT, keepNext: opt.keepNext || false,
});

const children = [];
let figN = 0;
for (const raw of lines) {
  const l = raw.replace(/\s+$/, "");
  if (!l.trim()) continue;
  if (l.startsWith("# ")) {
    children.push(new Paragraph({ children: runs(l.slice(2), { size: 32, bold: true }), alignment: AlignmentType.CENTER, spacing: { after: 240, line: 360 } }));
  } else if (l.startsWith("AUTHORS: ")) {
    children.push(new Paragraph({ children: runs(l.slice(9), { size: 24 }), alignment: AlignmentType.CENTER, spacing: { after: 120 } }));
  } else if (l.startsWith("AFFIL: ")) {
    children.push(new Paragraph({ children: runs(l.slice(7), { size: 20, italics: true }), alignment: AlignmentType.CENTER, spacing: { after: 60 } }));
  } else if (l.startsWith("CORR: ")) {
    children.push(new Paragraph({ children: runs(l.slice(6), { size: 20 }), alignment: AlignmentType.CENTER, spacing: { before: 120, after: 360 } }));
  } else if (l.startsWith("ABSTRACT: ")) {
    children.push(new Paragraph({ children: runs("Abstract", { size: 28, bold: true }), heading: HeadingLevel.HEADING_1, spacing: { before: 240, after: 120 } }));
    children.push(body(l.slice(10), { size: 22 }));
  } else if (l.startsWith("KEYWORDS: ")) {
    children.push(new Paragraph({ children: [...runs("Keywords: ", { size: 20, bold: true }), ...runs(l.slice(10), { size: 20 })], spacing: { after: 360, line: 360 } }));
  } else if (l.startsWith("## ")) {
    children.push(new Paragraph({ children: runs(l.slice(3), { size: 28, bold: true }), heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 120 }, keepNext: true }));
  } else if (l.startsWith("### ")) {
    children.push(new Paragraph({ children: runs(l.slice(4), { size: 24, bold: true, italics: true }), heading: HeadingLevel.HEADING_2, spacing: { before: 240, after: 120 }, keepNext: true }));
  } else if (l.startsWith("EQ: ")) {
    const [eq, num] = l.slice(4).split(" | ");
    children.push(new Paragraph({
      children: [...runs(eq, { size: 24 }), new TextRun({ text: "\t" + num, font: FONT, size: 24 })],
      alignment: AlignmentType.CENTER, spacing: { line: 360, before: 120, after: 240 },
      tabStops: [{ type: "right", position: 9026 }],
    }));
  } else if (l.startsWith("FIG: ")) {
    const [p, cap] = l.slice(5).split(" | ");
    const buf = fs.readFileSync(p);
    // read PNG size
    const w = buf.readUInt32BE(16), h = buf.readUInt32BE(20);
    const W = 600, H = Math.round(W * h / w);
    figN += 1;
    children.push(new Paragraph({ children: runs(`[Figure ${figN} near here]`, { size: 22, bold: true }), alignment: AlignmentType.CENTER, spacing: { before: 240, after: 120 } }));
    children.push(new Paragraph({ children: [new ImageRun({ data: buf, type: "png", transformation: { width: W, height: H } })], alignment: AlignmentType.CENTER, keepNext: true }));
    children.push(body(cap, { size: 20, line: 276, after: 360 }));
  } else if (l.startsWith("TAB: ")) {
    const [p, cap] = l.slice(5).split(" | ");
    children.push(new Paragraph({ children: runs(cap, { size: 20 }), spacing: { before: 240, after: 120, line: 276 }, keepNext: true }));
    const rows = fs.readFileSync(p, "utf8").trim().split("\n").map(r => r.split("\t"));
    const ncol = rows[0].length, total = 9026, cw = Math.floor(total / ncol);
    const border = { style: BorderStyle.SINGLE, size: 4, color: "808080" };
    const trs = rows.map((r, i) => new TableRow({ tableHeader: i === 0, children: r.map(c => new TableCell({
      width: { size: cw, type: WidthType.DXA },
      shading: i === 0 ? { type: ShadingType.CLEAR, fill: "E8EEF7", color: "auto" } : undefined,
      borders: { top: border, bottom: border, left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" }, right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" } },
      margins: { top: 40, bottom: 40, left: 60, right: 60 },
      children: [new Paragraph({ children: runs(c, { size: 16, bold: i === 0 }) })] })) }));
    children.push(new Table({ width: { size: cw * ncol, type: WidthType.DXA }, columnWidths: Array(ncol).fill(cw), rows: trs }));
    children.push(new Paragraph({ children: [], spacing: { after: 240 } }));
  } else if (l.startsWith("REF: ")) {
    children.push(new Paragraph({ children: runs(l.slice(5), { size: 19 }), spacing: { line: 276, after: 80 }, indent: { left: 360, hanging: 360 } }));
  } else {
    children.push(body(l));
  }
}

const doc = new Document({
  creator: "[AUTHOR]",
  title: lines.find(x => x.startsWith("# ")).slice(2),
  styles: { default: { document: { run: { font: FONT, size: 24, color: "000000" } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", run: { font: FONT, size: 28, bold: true, color: "000000" }, paragraph: { outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", run: { font: FONT, size: 24, bold: true, italics: true, color: "000000" }, paragraph: { outlineLevel: 1 } },
    ] },
  sections: [{
    properties: {
      page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } },
      lineNumbers: { countBy: 1, restart: LineNumberRestartFormat.CONTINUOUS, distance: 360 },
    },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
      children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 20 })] })] }) },
    children,
  }],
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync(OUT, b); console.log("wrote", OUT, children.length, "blocks"); });
