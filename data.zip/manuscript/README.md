# Manuscript source

`manuscript.md` is the single-source manuscript in a light markup consumed by
`build_docx.js` (see its header for the markup spec). Build the Word file with:

```bash
node build_docx.js manuscript.md manuscript.docx
```

Section files (`m_*.md`) are concatenated, in this order, into `manuscript.md`:
head, abstract, intro, methods, results, discussion, conclusions, figures,
backmatter, references. Figures are embedded from `../figures/*.png`; Table 1 is
read from `../results/table1_top_switches.md`. Equation numbers and figure/table
captions are defined inline. Author names, affiliations, funding and the Zenodo
DOI are placeholders in square brackets to be completed before submission.
