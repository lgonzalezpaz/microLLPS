# Arginine-rich neuronal microexons act as phase-separation switches across the human proteome

AUTHORS: [AUTHOR 1]^1^, [AUTHOR 2]^1^ and [CORRESPONDING AUTHOR]^1,^*

AFFIL: ^1^[Department, Institution, City, Country]

CORR: *Correspondence: [email] ([INITIALS])
